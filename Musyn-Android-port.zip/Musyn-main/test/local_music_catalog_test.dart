import 'package:flutter_test/flutter_test.dart';
import 'package:musyn/services/local_music_catalog.dart';
import 'package:musyn/utilities/app_utils.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('imported tracks keep metadata and skip duplicates', () {
    final first = mergeImportedTracks(const [], [
      {
        'id': 'local_abc',
        'title': 'Night Drive',
        'artist': 'Musyn',
        'album': 'Sessions',
        'duration': 184,
        'audioPath': '/music/night.mp3',
        'artworkPath': '/music/night.jpg',
        'fileName': 'night_drive.mp3',
        'contentHash': 'abc',
        'format': 'mp3',
      },
    ]);
    expect(first.added, 1);
    expect(first.tracks.single['title'], 'Night Drive');
    expect(first.tracks.single['album'], 'Sessions');
    expect(first.tracks.single['artist'], 'Musyn');
    expect(first.tracks.single['duration'], 184);
    expect(first.tracks.single['catalogOrigin'], 'local');
    expect(first.tracks.single['forceSource'], 'offline');
    expect(first.tracks.single['artworkPath'], '/music/night.jpg');

    final again = mergeImportedTracks(first.tracks, [
      {
        'id': 'local_abc',
        'audioPath': '/music/copy.mp3',
        'artworkPath': '/music/copy.jpg',
        'fileName': 'night_drive.mp3',
        'contentHash': 'abc',
        'format': 'mp3',
      },
      {
        'id': 'local_wav',
        'fileName': 'voice.wav',
        'audioPath': '/music/voice.wav',
        'format': 'wav',
        'contentHash': 'wav',
      },
      {
        'id': 'local_bad',
        'audioPath': '/music/notes.txt',
        'format': 'txt',
      },
    ]);
    expect(again.added, 1);
    expect(again.duplicates, 1);
    expect(again.rejected, 1);
    expect(again.tracks, hasLength(2));
    expect(again.tracks.last['title'], 'voice');
    expect(again.tracks.last['artist'], 'Unknown Artist');
    expect(
      again.pathsToDelete,
      containsAll(['/music/copy.mp3', '/music/copy.jpg', '/music/notes.txt']),
    );
    expect(again.pathsToDelete, isNot(contains('/music/night.mp3')));
  });

  test('local search matches title, artist and album', () {
    final tracks = [
      {
        'title': 'Night Drive',
        'artist': 'Musyn',
        'album': 'Sessions',
        'fileName': 'night.mp3',
      },
      {
        'title': 'Morning',
        'artist': 'Ada',
        'album': 'Dawn',
        'fileName': 'morning.flac',
      },
    ];
    expect(searchLocalTracks(tracks, 'session'), hasLength(1));
    expect(searchLocalTracks(tracks, 'ADA').single['title'], 'Morning');
    expect(localMusicSuggestions(tracks, 'night'), ['Night Drive']);
    expect(formatLocalDuration(0), '—');
    expect(formatLocalDuration(184), '3:04');
  });

  test('import summary explains skips and cancellation', () {
    expect(
      const LocalImportSummary(
        cancelled: true,
        added: 0,
        duplicates: 0,
        unsupported: 0,
        failed: 0,
        truncated: false,
      ).message,
      isEmpty,
    );
    expect(
      const LocalImportSummary(
        cancelled: false,
        added: 2,
        duplicates: 1,
        unsupported: 1,
        failed: 0,
        truncated: false,
      ).message,
      contains('Imported 2 songs'),
    );
    expect(
      const LocalImportSummary(
        cancelled: false,
        added: 0,
        duplicates: 0,
        unsupported: 0,
        failed: 0,
        truncated: false,
      ).message,
      'No supported audio files were selected.',
    );
  });

  test('regular YouTube is a catalog and local music is not', () {
    expect(
      songIsYoutubeCatalog({'catalogOrigin': 'youtube_video'}),
      isTrue,
    );
    expect(songIsYoutubeCatalog({'catalogOrigin': 'youtube'}), isTrue);
    expect(songIsYoutubeCatalog({'catalogOrigin': 'local'}), isFalse);
    expect(isYouTubeVideoSong({'source': 'youtube_video'}), isTrue);
    expect(isLocalCatalogSong({'catalogOrigin': 'local'}), isTrue);
  });
}
