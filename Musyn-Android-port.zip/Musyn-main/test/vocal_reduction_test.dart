import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:musyn/services/vocal_reduction.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const a = MediaItem(id: 'entry-a', title: 'A');
  const b = MediaItem(id: 'entry-b', title: 'B');
  late List<String> installed;
  late List<double> levels;
  late VocalReductionController controller;
  VocalReductionController make({
    VocalPrepare? prepare,
    Future<bool> Function(String, String)? install,
    Future<void> Function(double)? mix,
  }) => VocalReductionController(
    prepare:
        prepare ??
        (_, _, progress) async {
          progress('Separating', 0.5);
          return '/local/test.musyn-stems.mov';
        },
    install:
        install ??
        (id, path) async {
          installed.add(id);
          return true;
        },
    mix:
        mix ??
        (level) async {
          levels.add(level);
        },
    cancel: () async {},
  );
  setUp(() {
    installed = [];
    levels = [];
  });
  tearDown(() {
    controller.dispose();
  });
  test(
    'prepared stems retain queue entry identity and vocal control restores original',
    () async {
      controller = make();
      await controller.enable(a);
      expect(installed, ['entry-a']);
      expect(levels, [0]);
      expect(controller.phase, VocalPhase.ready);
      await controller.setLevel(0.4);
      await controller.disable();
      expect(levels, [0, 0.4, 1]);
      expect(controller.wanted, false);
    },
  );
  test(
    'late preparation after skip never installs on a different track',
    () async {
      final preparation = Completer<String>();
      controller = make(prepare: (_, _, _) => preparation.future);
      final work = controller.enable(a);
      controller.select(b);
      preparation.complete('/local/a.musyn-stems.mov');
      await work;
      expect(installed, isEmpty);
      expect(levels, isEmpty);
      expect(controller.phase, VocalPhase.off);
    },
  );
  test('cancel during installation never applies a muted mix', () async {
    final installation = Completer<bool>();
    controller = make(install: (_, _) => installation.future);
    final work = controller.enable(a);
    await Future<void>.delayed(Duration.zero);
    await controller.disable();
    installation.complete(true);
    await work;
    expect(levels, isEmpty);
    expect(controller.phase, VocalPhase.off);
  });
  test(
    'cancel during native mix restores original vocals after mix returns',
    () async {
      final mix = Completer<void>();
      controller = make(
        mix: (level) {
          levels.add(level);
          return level == 0 ? mix.future : Future.value();
        },
      );
      final work = controller.enable(a);
      await Future<void>.delayed(Duration.zero);
      await controller.disable();
      mix.complete();
      await work;
      expect(levels, [0, 1]);
      expect(controller.phase, VocalPhase.off);
    },
  );
  test(
    'metadata refresh does not reset prepared vocals, source changes do',
    () async {
      controller = make();
      await controller.enable(a);
      controller.select(
        a.copyWith(
          duration: const Duration(seconds: 180),
          extras: {'vocalMix': true},
        ),
      );
      expect(controller.phase, VocalPhase.ready);
      controller.select(a.copyWith(extras: {'resolvedSource': 'jiosaavn'}));
      expect(controller.phase, VocalPhase.off);
    },
  );
  test('failed installation does not poison a later retry', () async {
    var attempts = 0;
    controller = make(
      install: (_, _) async {
        if (++attempts == 1) throw StateError('native load failed');
        return true;
      },
    );
    await controller.enable(a);
    expect(controller.phase, VocalPhase.failed);
    await controller.enable(a);
    expect(controller.phase, VocalPhase.ready);
    expect(attempts, 2);
  });
  test('old cancelled mix cannot overwrite a newly enabled mix', () async {
    final oldMix = Completer<void>();
    var first = true;
    controller = make(
      mix: (level) {
        levels.add(level);
        if (first) {
          first = false;
          return oldMix.future;
        }
        return Future.value();
      },
    );
    final old = controller.enable(a);
    await Future<void>.delayed(Duration.zero);
    await controller.disable();
    await controller.enable(a);
    oldMix.complete();
    await old;
    expect(levels, [0, 0]);
    expect(controller.phase, VocalPhase.ready);
    expect(controller.level, 0);
  });
  test('failure never calls mix or replaces audio', () async {
    controller = make(
      prepare: (_, _, _) => Future.error(StateError('unavailable')),
    );
    await controller.enable(a);
    expect(controller.phase, VocalPhase.failed);
    expect(installed, isEmpty);
    expect(levels, isEmpty);
  });
  test(
    'upcoming availability gate never prepares, installs or changes audio',
    () async {
      var preparations = 0;
      controller = VocalReductionController(
        available: false,
        prepare: (_, _, _) async {
          preparations++;
          return '/unused.musyn-stems.mov';
        },
        install: (id, _) async {
          installed.add(id);
          return true;
        },
        mix: (level) async {
          levels.add(level);
        },
        cancel: () async {},
      );
      await controller.enable(a);
      expect(preparations, 0);
      expect(installed, isEmpty);
      expect(levels, isEmpty);
      expect(controller.wanted, isFalse);
      expect(controller.phase, VocalPhase.off);
      expect(controller.status, contains('coming soon'));
      expect(vocalReduction.available, isFalse);
    },
  );
  test(
    'selection and metadata updates never prepare or download vocals',
    () async {
      var calls = 0;
      controller = make(
        prepare: (_, _, _) async {
          calls++;
          return '/local/a.musyn-stems.mov';
        },
      );
      controller.select(a);
      controller.select(b);
      await Future<void>.delayed(Duration.zero);
      expect(calls, 0);
      await controller.enable(b);
      expect(calls, 1);
      await controller.disable();
      expect(calls, 1);
    },
  );
  test('prepared-cache identity survives signed URL and queue ID rotation', () {
    controller = make();
    const item = MediaItem(
      id: 'queue-a',
      title: 'A',
      extras: {
        'ytid': 'abcdefghijk',
        'resolvedSource': 'youtube',
        'resolvedBitrate': 128,
        'resolvedFormat': 'aac',
      },
    );
    final first = NativeVocalPreparation.cacheIdentity(
      item,
      Uri.parse(
        'https://a.googlevideo.com/videoplayback?id=recording&itag=140&expire=1',
      ),
    );
    expect(first, isNotNull);
    expect(
      NativeVocalPreparation.cacheIdentity(
        item.copyWith(id: 'queue-b'),
        Uri.parse(
          'https://b.googlevideo.com/videoplayback?id=recording&itag=140&expire=2',
        ),
      ),
      first,
    );
    expect(
      NativeVocalPreparation.cacheIdentity(
        item,
        Uri.parse('https://a.googlevideo.com/videoplayback?id=other&itag=140'),
      ),
      isNot(first),
    );
    expect(
      NativeVocalPreparation.cacheIdentity(
        item.copyWith(
          extras: {
            ...?item.extras,
            'resolvedSource': 'jiosaavn',
            'saavnId': 'different',
          },
        ),
        Uri.parse('https://cdn.example/audio.m4a'),
      ),
      isNot(first),
    );
    expect(
      NativeVocalPreparation.cacheIdentity(
        a,
        Uri.parse('https://unknown.example/audio'),
      ),
      isNull,
    );
    expect(
      NativeVocalPreparation.cacheIdentity(item, Uri.file('/local/song.m4a')),
      isNull,
    );
  });
}
