#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is required. Install Flutter 3.47.7 and Android SDK 36 first." >&2
  exit 1
fi

# This repository did not previously contain an Android platform folder or
# Gradle wrapper. Generate wrapper scripts in a temporary Flutter project.
if [[ ! -f android/gradlew || ! -f android/gradle/wrapper/gradle-wrapper.jar ]]; then
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  flutter create --platforms=android --org com.vorynlabs --project-name musyn "$TMP/bootstrap" >/dev/null
  mkdir -p android/gradle/wrapper
  cp "$TMP/bootstrap/android/gradlew" android/gradlew
  cp "$TMP/bootstrap/android/gradlew.bat" android/gradlew.bat
  cp "$TMP/bootstrap/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/
  cp "$TMP/bootstrap/android/gradle/wrapper/gradle-wrapper.properties" android/gradle/wrapper/
  chmod +x android/gradlew
fi

flutter pub get
flutter analyze
flutter test
flutter build apk --release --target-platform android-arm64
printf '\nAPK created at: %s\n' "$ROOT/build/app/outputs/flutter-apk/app-release.apk"
