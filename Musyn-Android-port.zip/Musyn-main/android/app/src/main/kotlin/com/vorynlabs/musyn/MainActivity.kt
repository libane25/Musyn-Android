package com.vorynlabs.musyn

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    private val providerChannel = "com.vorynlabs.musyn/provider_access"
    private val linksChannel = "com.vorynlabs.musyn/links"
    private val motionChannel = "com.vorynlabs.musyn/motion"
    private val artworkChannel = "com.vorynlabs.musyn/artwork"
    private val prefsName = "musyn_provider_secure"
    private val keyAlias = "musyn_provider_aes_gcm"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, linksChannel)
            .setMethodCallHandler { call, result ->
                if (call.method != "open") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val raw = call.arguments as? String
                val uri = runCatching { Uri.parse(raw ?: "") }.getOrNull()
                if (uri?.scheme != "https") {
                    result.success(false)
                } else {
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    }.onSuccess { result.success(it) }
                        .onFailure { result.success(false) }
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, providerChannel)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "read" -> result.success(readProviderKey())
                        "write" -> {
                            val value = call.argument<String>("value")
                            if (value == null || value.toByteArray(Charsets.UTF_8).size != 8) {
                                result.error("format", "Expected an 8-byte media URL key", null)
                            } else {
                                writeProviderKey(value)
                                result.success(null)
                            }
                        }
                        "delete" -> {
                            getSharedPreferences(prefsName, MODE_PRIVATE).edit().remove("key").apply()
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("secure_storage", "Could not access encrypted provider key", e.message)
                }
            }

        // iOS-only animated artwork and lock-screen lyric features are intentionally
        // reported as unsupported on Android; normal artwork/audio remains available.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, motionChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "supported" -> result.success(false)
                    "diagnostics" -> result.success(null)
                    "lyrics", "clear", "prepare", "cancel" -> result.success(null)
                    else -> result.notImplemented()
                }
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, artworkChannel)
            .setMethodCallHandler { call, result ->
                if (call.method == "squareCover") result.success(null) else result.notImplemented()
            }
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        val spec = android.security.keystore.KeyGenParameterSpec.Builder(
            keyAlias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun writeProviderKey(value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + encrypted
        getSharedPreferences(prefsName, MODE_PRIVATE).edit()
            .putString("key", Base64.encodeToString(combined, Base64.NO_WRAP)).apply()
    }

    private fun readProviderKey(): String? {
        val encoded = getSharedPreferences(prefsName, MODE_PRIVATE).getString("key", null) ?: return null
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        if (combined.size < 13) return null
        val iv = combined.copyOfRange(0, 12)
        val ciphertext = combined.copyOfRange(12, combined.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext).toString(Charsets.UTF_8)
    }
}
