import 'dart:convert';

import 'package:collection/collection.dart';
import 'package:http_parser/http_parser.dart';

import '../../extensions/helpers_extension.dart';
import '../../videos/streams/models/audio_track.dart';
import '../models/stream_info_provider.dart';

///
class PlayerResponse {
  // Json parsed map
  final JsonMap root;

  ///
  late final String playabilityStatus =
      root.getJson<String>('playabilityStatus/status') ?? '';

  ///
  bool get isVideoAvailable => playabilityStatus.toLowerCase() != 'error';

  ///
  bool get isVideoPlayable => playabilityStatus.toLowerCase() == 'ok';

  ///
  String get videoTitle => root.getJson<String>('videoDetails/title') ?? '';

  ///
  String get videoAuthor => root.getJson<String>('videoDetails/author') ?? '';

  ///
  DateTime? get videoUploadDate => root
      .getJson<String>('microformat/playerMicroformatRenderer/uploadDate')
      ?.parseDateTime();

  ///
  DateTime? get videoPublishDate => root
      .getJson<String>('microformat/playerMicroformatRenderer/publishDate')
      ?.parseDateTime();

  ///
  String get videoChannelId =>
      root.getJson<String>('videoDetails/channelId') ?? '';

  ///
  Duration get videoDuration => Duration(
        seconds: int.tryParse(
                root.getJson<String>('videoDetails/lengthSeconds') ?? '') ??
            0,
      );

  ///
  List<String> get videoKeywords =>
      root.getJson<List<dynamic>>('videoDetails/keywords')?.cast<String>() ??
      const [];

  ///
  String get videoDescription =>
      root.getJson<String>('videoDetails/shortDescription') ?? '';

  ///
  int get videoViewCount =>
      int.tryParse(root.getJson<String>('videoDetails/viewCount') ?? '') ?? 0;

  ///
  String? get previewVideoId =>
      root.getJson<String>(
        'playabilityStatus/errorScreen/playerLegacyDesktopYpcTrailerRenderer/trailerVideoId',
      ) ??
      Uri.splitQueryString(
        root.getJson<String>(
              'playabilityStatus/errorScreen//ypcTrailerRenderer/playerVars',
            ) ??
            '',
      )['video_id'] ??
      root
          .getJson<String>(
            'playabilityStatus/errorScreen/ypcTrailerRenderer/playerResponse',
          )
          // From https://github.com/Tyrrrz/YoutubeExplode
          // YouTube uses weird base64-like encoding here that I don't know how to deal with.
          // It's supposed to have JSON inside, but if extracted as is, it contains garbage.
          // Luckily, some of the text gets decoded correctly, which is enough for us to
          // extract the preview video ID using regex.
          ?.replaceAll('-', '+')
          .replaceAll('_', '/')
          .pipe((e) => base64.decode(e))
          .pipe((e) => utf8.decode(e, allowMalformed: true))
          .pipe(
            (value) => RegExp('video_id=(.{11})').firstMatch(value)?.group(1),
          )
          ?.nullIfWhitespace;

  ///
  bool get isLive => root.getJson<bool>('videoDetails/isLive') ?? false;

  ///
  String? get hlsManifestUrl =>
      root.getJson<String>('streamingData/hlsManifestUrl');

  ///
  String? get dashManifestUrl =>
      root.getJson<String>('streamingData/dashManifestUrl');

  ///
  late final List<StreamInfoProvider> muxedStreams = root
          .getJson<List<dynamic>>('streamingData/formats')
          ?.map((e) => _StreamInfo(e as JsonMap, StreamSource.muxed))
          .toList() ??
      const <StreamInfoProvider>[];

  ///
  late final List<StreamInfoProvider> adaptiveStreams = root
          .getJson<List<dynamic>>('streamingData/adaptiveFormats')
          ?.map((e) => _StreamInfo(e as JsonMap, StreamSource.adaptive))
          .toList() ??
      const [];

  ///
  late final List<StreamInfoProvider> streams = [
    ...muxedStreams,
    ...adaptiveStreams,
  ];

  ///
  late final List<ClosedCaptionTrack> closedCaptionTrack = root
          .getJson<List<dynamic>>(
            'captions/playerCaptionsTracklistRenderer/captionTracks',
          )
          ?.map((e) => ClosedCaptionTrack(e as JsonMap))
          .cast<ClosedCaptionTrack>()
          .toList() ??
      const [];

  ///
  late final String? videoPlayabilityError =
      root.getJson<String>('playabilityStatus/reason');

  PlayerResponse(this.root);

  ///
  PlayerResponse.parse(String raw) : root = _parseRoot(raw);

  static JsonMap _parseRoot(String raw) {
    try {
      final decoded = json.decode(raw);
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return decoded.cast<String, dynamic>();
    } catch (_) {}
    return {
      'playabilityStatus': {
        'status': 'ERROR',
        'reason': 'Invalid player response payload',
      },
    };
  }
}

///
class ClosedCaptionTrack {
  // Json parsed class
  final JsonMap root;

  ///
  String get url => root.getT<String>('baseUrl') ?? '';

  ///
  String get languageCode => root.getT<String>('languageCode') ?? '';

  ///
  String? get languageName => root.getJson<String>('name/simpleText');

  ///
  bool get autoGenerated =>
      root.getT<String>('vssId')?.toLowerCase().startsWith('a.') ?? false;

  ///
  ClosedCaptionTrack(this.root);
}

class _StreamInfo extends StreamInfoProvider {
  static final _contentLenExp = RegExp(r'[\?&]clen=(\d+)');

  /// Json parsed map
  final JsonMap root;

  @override
  late final int? bitrate = root.getT<int>('bitrate');

  @override
  late final String container = codec.subtype;

  @override
  late final int? contentLength = int.tryParse(
    root.getT<String>('contentLength') ??
        _contentLenExp.firstMatch(url)?.group(1) ??
        '',
  );

  @override
  late final int? framerate = root.getT<int>('fps');

  @override
  late final String? signature =
      Uri.splitQueryString(root.getT<String>('signatureCipher') ?? '')['s'];

  @override
  late final String? signatureParameter = Uri.splitQueryString(
        root.getT<String>('cipher') ?? '',
      )['sp'] ??
      Uri.splitQueryString(root.getT<String>('signatureCipher') ?? '')['sp'];

  @override
  late final int tag = root.getT<int>('itag') ?? 0;

  @override
  late final String url = root.getT<String>('url') ??
      Uri.splitQueryString(root.getT<String>('cipher') ?? '')['url'] ??
      Uri.splitQueryString(root.getT<String>('signatureCipher') ?? '')['url'] ??
      '';

  @override
  late final String? videoCodec = isAudioOnly
      ? null
      : codecs?.split(',').firstOrNull?.trim().nullIfWhitespace;

  @override
  late final int? videoHeight = root.getT<int>('height');

  @override
  @Deprecated('Use qualityLabel')
  String get videoQualityLabel => qualityLabel;

  @override
  late final String qualityLabel = root.getT<String>('qualityLabel') ?? '';

  @override
  late final int? videoWidth = root.getT<int>('width');

  late final bool isAudioOnly = codec.type == 'audio';

  @override
  late final MediaType codec =
      _getMimeType() ?? MediaType('application', 'octet-stream');

  @override
  late final AudioTrack? audioTrack = () {
    if (root.containsKey('audioTrack')) {
      final name = root.getJson<String>('audioTrack/displayName');
      final id = root.getJson<String>('audioTrack/id');
      final isDefault = root.getJson<bool>('audioTrack/audioIsDefault');
      if (name != null && id != null && isDefault != null) {
        return AudioTrack(
          displayName: name,
          id: id,
          audioIsDefault: isDefault,
        );
      }
    }
    return null;
  }();

  MediaType? _getMimeType() {
    final mime = root.getT<String>('mimeType');
    if (mime == null) {
      return null;
    }
    return MediaType.parse(mime);
  }

  late final String? codecs = codec.parameters['codecs']?.toLowerCase();

  @override
  late final String? audioCodec =
      isAudioOnly ? codecs : _getAudioCodec(codecs?.split(','))?.trim();

  String? _getAudioCodec(List<String>? codecs) {
    if (codecs == null) {
      return null;
    }
    if (codecs.length == 1) {
      return null;
    }
    return codecs.last;
  }

  @override
  final StreamSource source;

  _StreamInfo(this.root, this.source);
}

extension PipeExt<T extends Object?> on T {
  R pipe<R>(R Function(T value) f) => f(this);
}
