import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:musyn/services/audio/audio_runtime.dart';
import 'package:musyn/services/local_music_catalog.dart';
import 'package:musyn/services/local_music_library.dart';
import 'package:musyn/theme/app_themes.dart';
import 'package:musyn/theme/musyn_style.dart';
import 'package:musyn/utilities/flutter_toast.dart';
import 'package:musyn/utilities/mediaitem.dart';
import 'package:musyn/utilities/song_info_dialog.dart';
import 'package:musyn/widgets/content_state.dart';
import 'package:musyn/widgets/mini_player_bottom_space.dart';
import 'package:musyn/widgets/song_artwork.dart';

void showImportMusicSheet(BuildContext context) {
  showCupertinoModalPopup<void>(
    context: context,
    builder: (sheet) => CupertinoActionSheet(
      title: const Text('Import Music'),
      message: const Text(
        'Choose audio files or a folder. Musyn copies supported songs into its private storage so they keep playing after the picker closes. It does not ask for access to every file on the device.',
      ),
      actions: [
        CupertinoActionSheetAction(
          onPressed: () {
            Navigator.pop(sheet);
            unawaited(_runImport(context, folder: false));
          },
          child: const Text('Choose audio files'),
        ),
        CupertinoActionSheetAction(
          onPressed: () {
            Navigator.pop(sheet);
            unawaited(_runImport(context, folder: true));
          },
          child: const Text('Choose a folder'),
        ),
      ],
      cancelButton: CupertinoActionSheetAction(
        onPressed: () => Navigator.pop(sheet),
        child: const Text('Cancel'),
      ),
    ),
  );
}

Future<void> _runImport(BuildContext context, {required bool folder}) async {
  final navigator = Navigator.of(context, rootNavigator: true);
  var dialogVisible = false;
  unawaited(
    showCupertinoDialog<void>(
      context: context,
      builder: (_) {
        dialogVisible = true;
        return const CupertinoAlertDialog(
          content: Padding(
            padding: EdgeInsets.only(top: 8),
            child: Column(
              children: [
                CupertinoActivityIndicator(),
                SizedBox(height: 12),
                Text('Importing music…'),
              ],
            ),
          ),
        );
      },
    ),
  );
  await WidgetsBinding.instance.endOfFrame;
  LocalImportSummary summary;
  try {
    summary = folder
        ? await LocalMusicLibrary.instance.importFolder()
        : await LocalMusicLibrary.instance.importFiles();
  } catch (_) {
    summary = const LocalImportSummary(
      cancelled: false,
      added: 0,
      duplicates: 0,
      unsupported: 0,
      failed: 1,
      truncated: false,
    );
  }
  if (dialogVisible && navigator.mounted) navigator.pop();
  if (!context.mounted || summary.cancelled) return;
  final message = summary.failed > 0 && summary.added == 0 && summary.duplicates == 0
      ? 'Could not import music. Try again.'
      : summary.message;
  if (message.isNotEmpty) showToast(context, message);
}

class LocalMusicPage extends StatefulWidget {
  const LocalMusicPage({super.key});

  @override
  State<LocalMusicPage> createState() => _LocalMusicPageState();
}

class _LocalMusicPageState extends State<LocalMusicPage> {
  final TextEditingController _query = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (LocalMusicLibrary.instance.tracks.value.isEmpty) {
      unawaited(LocalMusicLibrary.instance.load());
    }
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _visible(List<Map<String, dynamic>> tracks) =>
      searchLocalTracks(tracks, _query.text);

  Future<void> _play(List<Map<String, dynamic>> tracks, int index) async {
    final song = tracks[index];
    if (song['missing'] == true) {
      showToast(context, 'This file is no longer available.');
      return;
    }
    final playable = <Map<String, dynamic>>[];
    var playIndex = 0;
    for (var i = 0; i < tracks.length; i++) {
      if (tracks[i]['missing'] == true) continue;
      if (i == index) playIndex = playable.length;
      playable.add(tracks[i]);
    }
    if (playable.isEmpty) {
      showToast(context, 'No playable songs in Local Music.');
      return;
    }
    await audioHandler.playPlaylistSong(
      playlist: {'list': playable},
      songIndex: playIndex,
    );
  }

  Future<void> _confirmRemove(Map song) async {
    final id = song['ytid']?.toString() ?? '';
    if (id.isEmpty) return;
    final title = song['title']?.toString() ?? 'this song';
    final remove = await showCupertinoDialog<bool>(
      context: context,
      builder: (dialog) => CupertinoAlertDialog(
        title: const Text('Remove from Local Music'),
        content: Text(
          'Remove “$title” from Musyn? The copied audio file is deleted. The original file you picked is left where it was.',
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: () => Navigator.pop(dialog, false),
            child: const Text('Cancel'),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            onPressed: () => Navigator.pop(dialog, true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (remove == true) {
      await LocalMusicLibrary.instance.remove(id);
      if (mounted) showToast(context, 'Removed from Local Music');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = isAppDarkMode(context);
    return CupertinoPageScaffold(
      backgroundColor: musynCanvas(isDark),
      child: SafeArea(
        bottom: false,
        child: ValueListenableBuilder<List<Map<String, dynamic>>>(
          valueListenable: LocalMusicLibrary.instance.tracks,
          builder: (context, tracks, _) {
            final visible = _visible(tracks);
            final missing = tracks.where((song) => song['missing'] == true).length;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                  child: Row(
                    children: [
                      const CupertinoNavigationBarBackButton(),
                      Expanded(
                        child: Text(
                          'Local Music',
                          style: MusynStyle.largeTitle(
                            CupertinoTheme.of(context).textTheme.textStyle.color!,
                          ),
                        ),
                      ),
                      CupertinoButton(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        onPressed: () => showImportMusicSheet(context),
                        child: const Icon(CupertinoIcons.add),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
                  child: CupertinoSearchTextField(
                    controller: _query,
                    placeholder: 'Search imported songs',
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                Expanded(
                  child: tracks.isEmpty
                      ? ListView(
                          children: [
                            ContentState(
                              icon: CupertinoIcons.music_note_list,
                              title: 'No local music yet',
                              message:
                                  'Import MP3, M4A, AAC, FLAC, WAV, or OGG files. Musyn keeps a copy so the songs stay in your library.',
                              actionLabel: 'Import Music',
                              onAction: () => showImportMusicSheet(context),
                            ),
                          ],
                        )
                      : ListView.builder(
                          keyboardDismissBehavior:
                              ScrollViewKeyboardDismissBehavior.onDrag,
                          itemCount:
                              (visible.isEmpty ? 2 : visible.length + 1) + 1,
                          itemBuilder: (context, index) {
                            final footer =
                                visible.isEmpty ? 2 : visible.length + 1;
                            if (index == footer) {
                              return const MiniPlayerBottomSpace();
                            }
                            if (index == 0) {
                              return _toolbar(tracks, visible, missing);
                            }
                            if (visible.isEmpty) {
                              return const ContentState(
                                title: 'No matches',
                                message:
                                    'Try another title, artist, or album.',
                              );
                            }
                            final song = visible[index - 1];
                            return _row(song, () => _play(visible, index - 1));
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _toolbar(
    List<Map<String, dynamic>> tracks,
    List<Map<String, dynamic>> visible,
    int missing,
  ) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 12, 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              missing > 0
                  ? '${tracks.length} songs · $missing missing'
                  : '${tracks.length} ${tracks.length == 1 ? 'song' : 'songs'}',
              style: const TextStyle(
                fontFamily: MusynStyle.uiFont,
                color: CupertinoColors.systemGrey,
              ),
            ),
          ),
          if (missing > 0)
            CupertinoButton(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              onPressed: () async {
                final removed = await LocalMusicLibrary.instance.removeMissing();
                if (mounted) {
                  showToast(
                    context,
                    removed == 0
                        ? 'No missing songs to remove'
                        : 'Removed $removed missing ${removed == 1 ? 'song' : 'songs'}',
                  );
                }
              },
              child: const Text('Remove missing'),
            ),
          if (visible.any((song) => song['missing'] != true))
            CupertinoButton(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              onPressed: () => _play(visible, visible.indexWhere((song) => song['missing'] != true)),
              child: const Text('Play'),
            ),
        ],
      ),
    );
  }

  Widget _row(Map<String, dynamic> song, VoidCallback onPlay) {
    final missing = song['missing'] == true;
    final album = song['album']?.toString();
    final artist = song['artist']?.toString() ?? 'Unknown Artist';
    final details = [
      artist,
      if (album != null && album.isNotEmpty) album,
      formatLocalDuration(song['duration']),
    ].join(' · ');
    return CupertinoButton(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      onPressed: onPlay,
      child: Row(
        children: [
          Opacity(
            opacity: missing ? 0.45 : 1,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SongArtworkWidget(
                metadata: mapToMediaItem(song),
                size: 52,
                borderRadius: 8,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  song['title']?.toString() ?? 'Unknown Title',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: MusynStyle.uiFont,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: missing
                        ? CupertinoColors.systemGrey
                        : CupertinoTheme.of(context).textTheme.textStyle.color,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  missing ? 'File missing · $details' : details,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: MusynStyle.uiFont,
                    fontSize: 13,
                    color: CupertinoColors.systemGrey,
                  ),
                ),
              ],
            ),
          ),
          CupertinoButton(
            padding: const EdgeInsets.all(4),
            onPressed: () => _actions(song),
            child: const Icon(CupertinoIcons.ellipsis, size: 18),
          ),
        ],
      ),
    );
  }

  void _actions(Map song) {
    showCupertinoModalPopup<void>(
      context: context,
      builder: (sheet) => CupertinoActionSheet(
        title: Text(song['title']?.toString() ?? 'Song'),
        actions: [
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(sheet);
              showSongInfoDialog(context, song);
            },
            child: const Text('Track Details'),
          ),
          CupertinoActionSheetAction(
            isDestructiveAction: true,
            onPressed: () {
              Navigator.pop(sheet);
              unawaited(_confirmRemove(song));
            },
            child: const Text('Remove from Local Music'),
          ),
        ],
        cancelButton: CupertinoActionSheetAction(
          onPressed: () => Navigator.pop(sheet),
          child: const Text('Cancel'),
        ),
      ),
    );
  }
}
