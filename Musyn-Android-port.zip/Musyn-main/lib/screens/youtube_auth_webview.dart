import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:musyn/services/logger_service.dart';
import 'package:musyn/services/youtube_auth_service.dart';
import 'package:musyn/services/youtube_music_sync_service.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

const _cookieChannel = MethodChannel('com.vorynlabs.musyn/cookies');
const _loginWebViewChannel = MethodChannel('com.vorynlabs.musyn/login_webview');

const _loginUserAgent =
    'Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';

const _cookieUrls = [
  'https://music.youtube.com',
  'https://www.youtube.com',
  'https://youtube.com',
  'https://accounts.google.com',
  'https://www.google.com',
];

final _loginUri = Uri.https('accounts.google.com', '/ServiceLogin', {
  'service': 'youtube',
  'passive': 'true',
  'continue': 'https://music.youtube.com/',
});

class YouTubeAuthWebView extends StatefulWidget {
  const YouTubeAuthWebView({super.key});

  @override
  State<YouTubeAuthWebView> createState() => _YouTubeAuthWebViewState();
}

class _YouTubeAuthWebViewState extends State<YouTubeAuthWebView> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _isCompleting = false;
  bool _needsRetry = false;
  bool _prepared = false;
  int _extractGeneration = 0;

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_loginUserAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            if (mounted) {
              setState(() {
                _isLoading = true;
                _needsRetry = false;
              });
            }
            unawaited(_hideEmbeddedBrowser());
            unawaited(_prepareAndroidWebView());
          },
          onPageFinished: (String url) {
            if (mounted) {
              setState(() => _isLoading = false);
            }
            if (_isMusicHost(url)) unawaited(_extractCookiesAndComplete());
          },
          onNavigationRequest: (NavigationRequest request) {
            return NavigationDecision.navigate;
          },
          onUrlChange: (UrlChange change) {
            final url = change.url;
            if (url != null && _isMusicHost(url)) {
              unawaited(_extractCookiesAndComplete());
            }
          },
        ),
      );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(_startLogin());
    });
  }

  bool _isMusicHost(String url) =>
      Uri.tryParse(url)?.host == 'music.youtube.com';

  Future<void> _startLogin() async {
    await _controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await _controller.setUserAgent(_loginUserAgent);
    await _prepareAndroidWebView();
    for (var attempt = 0; attempt < 8; attempt++) {
      if (await _hideEmbeddedBrowser()) break;
      await Future<void>.delayed(const Duration(milliseconds: 40));
    }
    if (!mounted) return;
    await _controller.loadRequest(_loginUri);
  }

  Future<bool> _hideEmbeddedBrowser() async {
    if (kIsWeb || !Platform.isAndroid) return true;
    try {
      return await _loginWebViewChannel.invokeMethod<bool>(
            'prepare',
            _loginUserAgent,
          ) ??
          false;
    } catch (e) {
      logger.log('Could not hide the embedded browser: $e');
      return false;
    }
  }

  Future<void> _prepareAndroidWebView() async {
    if (_prepared) return;
    final platform = _controller.platform;
    if (platform is! AndroidWebViewController) {
      _prepared = true;
      return;
    }
    final cookies = WebViewCookieManager().platform;
    if (cookies is! AndroidWebViewCookieManager) return;
    try {
      await cookies.setAcceptThirdPartyCookies(platform, true);
      _prepared = true;
    } catch (e) {
      logger.log('Third-party cookies not ready: $e');
    }
  }

  Future<void> _extractCookiesAndComplete() async {
    if (_isCompleting) return;
    final generation = ++_extractGeneration;
    for (var attempt = 0; attempt < 5; attempt++) {
      if (!mounted || _isCompleting || generation != _extractGeneration) {
        return;
      }
      if (attempt > 0) {
        await Future<void>.delayed(const Duration(milliseconds: 600));
        if (!mounted || _isCompleting || generation != _extractGeneration) {
          return;
        }
      }
      try {
        final cookies = await _collectCookies();
        final hasRequired =
            cookies.containsKey('SAPISID') ||
            cookies.containsKey('__Secure-3PAPISID');
        if (!hasRequired) continue;
        _isCompleting = true;
        await YouTubeAuthService().saveCookies(cookies);
        unawaited(YouTubeMusicSyncService().fullSync());
        if (mounted && Navigator.canPop(context)) {
          Navigator.pop(context, true);
        }
        return;
      } catch (e) {
        logger.log('Error extracting cookies: $e');
      }
    }
    if (mounted && generation == _extractGeneration) {
      setState(() => _needsRetry = true);
    }
  }

  Future<Map<String, String>> _collectCookies() async {
    if (!kIsWeb && Platform.isAndroid) {
      try {
        final raw = await _cookieChannel.invokeMethod<Map<Object?, Object?>>(
          'read',
          _cookieUrls,
        );
        if (raw != null && raw.isNotEmpty) {
          return raw.map(
            (key, value) => MapEntry(key.toString(), value.toString()),
          );
        }
      } catch (e) {
        logger.log('Native cookie read failed: $e');
      }
    }

    final manager = WebViewCookieManager();
    final cookies = <String, String>{};
    for (final url in _cookieUrls) {
      final found = await manager.getCookies(domain: Uri.parse(url));
      for (final cookie in found) {
        if (cookie.name.isEmpty) continue;
        cookies[cookie.name] = cookie.value;
      }
    }
    return cookies;
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: const Text('Connect YouTube Music'),
        leading: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () => Navigator.pop(context, false),
          child: const Icon(CupertinoIcons.clear),
        ),
      ),
      child: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: _controller),
            if (_isLoading)
              const Center(child: CupertinoActivityIndicator(radius: 14)),
            if (_needsRetry)
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemBackground.resolveFrom(
                      context,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x33000000),
                        blurRadius: 16,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'YouTube Music opened, but Musyn could not save the session. Sign in again, then stay on YouTube Music until this screen closes.',
                        textAlign: TextAlign.center,
                      ),
                      CupertinoButton(
                        onPressed: () {
                          setState(() => _needsRetry = false);
                          unawaited(_controller.loadRequest(_loginUri));
                        },
                        child: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
