import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:musyn/constants/app_constants.dart';
import 'package:musyn/extensions/l10n.dart';
import 'package:musyn/screens/playlist_page.dart';
import 'package:musyn/services/artist_service.dart';
import 'package:musyn/services/audio/audio_runtime.dart';
import 'package:musyn/services/navigation_paths.dart';
import 'package:musyn/services/playlists_manager.dart';
import 'package:musyn/services/settings_manager.dart';
import 'package:musyn/theme/app_themes.dart';
import 'package:musyn/theme/musyn_style.dart';
import 'package:musyn/utilities/app_utils.dart';
import 'package:musyn/utilities/async_loader.dart';
import 'package:musyn/utilities/flutter_toast.dart';
import 'package:musyn/widgets/artist_shelf.dart';
import 'package:musyn/widgets/content_state.dart';
import 'package:musyn/widgets/mini_player_bottom_space.dart';
import 'package:musyn/widgets/playlist_cube.dart';
import 'package:musyn/widgets/playlist_page/add_to_playlist_button.dart';
import 'package:musyn/widgets/playlist_page/download_button.dart';
import 'package:musyn/widgets/playlist_page/like_button.dart';
import 'package:musyn/widgets/playlist_page/playlist_action_buttons.dart';
import 'package:musyn/widgets/playlist_page/playlist_header.dart';
import 'package:musyn/widgets/section_header.dart';
import 'package:musyn/widgets/song_tile.dart';
import 'package:musyn/widgets/spinner.dart';

/// The page an artist opens on: who the artist is, its top songs, its releases
/// and related artists.
class ArtistPage extends StatefulWidget {
  const ArtistPage({
    super.key,
    required this.artistId,
    this.artistData,
    this.loadArtist,
  });
  final Future<Map<String, dynamic>?> Function(String)? loadArtist;

  final String artistId;
  final Map? artistData;

  @override
  State<ArtistPage> createState() => _ArtistPageState();
}

class _ArtistPageState extends State<ArtistPage> {
  /// Read the first time the page is shown online, and left alone offline,
  /// where the artist is its downloaded songs and there is nothing to read.
  Future<Map<String, dynamic>?>? _artistFuture;

  Map<String, dynamic>? _artist;
  Map<String, dynamic>? _catalog;
  Future<Map?>? _catalogFuture;
  List<Map<String, dynamic>> _topSongs = const [];
  List<Map<String, dynamic>> _albums = const [];
  List<Map<String, dynamic>> _singles = const [];
  List<Map<String, dynamic>> _relatedArtists = const [];

  /// Whether the songs of the artist are being read for the play buttons.
  final _isLoadingCatalog = ValueNotifier<bool>(false);

  /// Cache for the resolved artist ID to avoid repeated lookups.
  String? _cachedResolvedArtistId;

  /// Cache for the artist title to avoid repeated lookups.
  String? _cachedArtistTitle;

  int _artistLoadGeneration = 0;

  /// Refresh artist data, preserving current state on failure.
  Future<void> _refresh() async {
    final generation = ++_artistLoadGeneration;
    final loaded = _artistFuture;
    _catalogFuture = null;
    final refreshed = _loadArtist(forceRefresh: true, refreshCatalog: true);
    // Block syntax: setState doesn't accept Future-returning callbacks
    setState(() {
      _artistFuture = refreshed;
    });

    Map<String, dynamic>? refreshedArtist;
    try {
      refreshedArtist = await refreshed;
    } catch (_) {
      refreshedArtist = null;
    }
    if (!mounted ||
        generation != _artistLoadGeneration ||
        refreshedArtist != null) {
      return;
    }
    setState(() {
      _artistFuture = loaded;
    });
    showToast(context, context.l10n.error);
  }

  @override
  void didUpdateWidget(covariant ArtistPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Artist identity is determined by ID only (data seed changes on rebuild)
    if (oldWidget.artistId != widget.artistId) {
      _artistLoadGeneration++;
      _artistFuture = null;
      _catalog = null;
      _catalogFuture = null;
      _cachedResolvedArtistId = null;
      _cachedArtistTitle = null;
    }
  }

  @override
  void dispose() {
    _isLoadingCatalog.dispose();
    super.dispose();
  }

  String get _resolvedArtistId => _cachedResolvedArtistId ??=
      _artist?['ytid']?.toString() ?? widget.artistId;

  String get _artistTitle => _cachedArtistTitle ??=
      _artist?['title']?.toString() ??
      widget.artistData?['title']?.toString() ??
      '';

  Future<Map<String, dynamic>?> _loadArtist({
    bool forceRefresh = false,
    bool refreshCatalog = false,
  }) async {
    final generation = _artistLoadGeneration;
    final artistData = widget.artistData;
    final artist =
        await (widget.loadArtist?.call(widget.artistId) ??
                getArtistProfile(
                  widget.artistId,
                  forceRefresh: forceRefresh,
                  cacheResult: !refreshCatalog,
                  preferredName: artistData?['title']?.toString(),
                  preferredImage: artistData?['image']?.toString(),
                  sourceSongId: artistData?['sourceSongId']?.toString(),
                  sourceVideoAuthor: artistData?['videoAuthor']?.toString(),
                  preferredVerified: artistData?['isVerifiedArtist'] == true,
                ))
            .timeout(const Duration(seconds: 20));
    if (artist == null || !mounted || generation != _artistLoadGeneration) {
      return null;
    }

    Map<String, dynamic>? catalog;
    if (refreshCatalog) {
      catalog = await getArtistCatalogFromProfile(
        artist,
        forceRebuild: true,
      ).timeout(const Duration(seconds: 20));
      if (catalog == null ||
          catalog['catalogStatus'] == 'failed' ||
          !mounted ||
          generation != _artistLoadGeneration) {
        return null;
      }
      cacheArtistProfileInBackground(artist);
    }

    _artist = artist;
    if (refreshCatalog) {
      _catalog = catalog;
      _catalogFuture = null;
    }
    // Clear caches when artist data updates
    _cachedResolvedArtistId = null;
    _cachedArtistTitle = null;
    // Each entry of the shelf is a song and its play count, side by side.
    final topSongs = asMapList(
      artist['topSongs'],
    ).where((entry) => entry['song'] is Map).toList();
    _topSongs = [
      for (final entry in topSongs)
        Map<String, dynamic>.from(entry['song'] as Map),
    ];
    _relatedArtists = asMapList(artist['relatedArtists']);
    // Split the discography once per load: the two shelves are rebuilt on every
    // frame and would otherwise filter it again each time.
    final releases = asMapList(artist['releases']);
    _albums = releases.where((r) => !isSingleOrEpRelease(r)).toList();
    _singles = releases.where(isSingleOrEpRelease).toList();
    return artist;
  }

  @override
  Widget build(BuildContext context) {
    if (offlineMode.value) return _buildAllSongsPage();

    final isDark = isAppDarkMode(context);
    final navBarColor = isDark
        ? const Color(0xB3121214)
        : const Color(0xB3FFFFFF);

    return AsyncLoader<Map<String, dynamic>?>(
      future: _artistFuture ??= _loadArtist(),
      loadingWidget: CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(backgroundColor: navBarColor),
        child: const Center(child: Spinner()),
      ),
      emptyWidget: _buildNotFoundPage(),
      errorBuilder: (_, _, _) => _buildNotFoundPage(),
      builder: (context, _) => CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(backgroundColor: navBarColor),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: commonSingleChildScrollViewPadding,
            child: Column(
              children: [
                _buildHeaderSection(),
                _buildTopSongsSection(),
                if (_albums.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: ArtistShelf(
                      title: context.l10n.albums,
                      icon: CupertinoIcons.music_albums,
                      items: _albums,
                      subtitleOf: _releaseSubtitle,
                      onTap: _openRelease,
                    ),
                  ),
                if (_singles.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: ArtistShelf(
                      title: context.l10n.singlesAndEps,
                      icon: CupertinoIcons.music_note_2,
                      items: _singles,
                      subtitleOf: _releaseSubtitle,
                      onTap: _openRelease,
                    ),
                  ),
                if (_relatedArtists.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: ArtistShelf(
                      title: context.l10n.suggestedArtists,
                      icon: CupertinoIcons.person_crop_circle,
                      items: _relatedArtists,
                      cubeIcon: CupertinoIcons.person_crop_circle_fill,
                      circular: true,
                      onTap: _openArtist,
                    ),
                  ),
                const SizedBox(height: 16),
                const MiniPlayerBottomSpace(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// The artist as its song list, which offline is the whole page.
  Widget _buildAllSongsPage() {
    return PlaylistPage(
      playlistId: widget.artistId,
      playlistData: artistPlaylistData({
        'ytid': widget.artistId,
        'title': _artistTitle,
        'image': _artist?['image'] ?? widget.artistData?['image'],
      }),
      cubeIcon: CupertinoIcons.person_crop_circle_fill,
      isArtist: true,
    );
  }

  Widget _buildNotFoundPage() => CupertinoPageScaffold(
    navigationBar: const CupertinoNavigationBar(middle: Text('Artist')),
    child: SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: [
            ContentState(
              icon: CupertinoIcons.person_crop_circle,
              title: 'Artist unavailable',
              message:
                  'This artist could not be loaded. Try again or search by name.',
              actionLabel: 'Retry artist',
              onAction: () => setState(() {
                _artistFuture = _loadArtist();
              }),
              secondaryLabel: 'Search for artist',
              onSecondary: () => context.go(
                Uri(
                  path: '/search',
                  queryParameters: {
                    'q':
                        widget.artistData?['title']?.toString() ??
                        widget.artistId,
                  },
                ).toString(),
              ),
            ),
            const MiniPlayerBottomSpace(),
          ],
        ),
      ),
    ),
  );

  Widget _buildHeaderSection() {
    final screenSize = MediaQuery.sizeOf(context);
    final isLandscape = screenSize.width > screenSize.height;
    final isDark = isAppDarkMode(context);
    final artistMap = _artist ?? widget.artistData ?? const <String, dynamic>{};

    return Column(
      children: [
        PlaylistHeader(
          PlaylistCube(
            artistMap,
            size: isLandscape
                ? 250
                : screenSize.width / commonPlaylistArtworkDivision,
            cubeIcon: CupertinoIcons.person_crop_circle_fill,
            showTypeLabel: false,
          ),
          _artistTitle,
          isArtist: true,
          monthlyListeners: artistMap['monthlyListeners']?.toString(),
          description: artistMap['description']?.toString(),
        ),
        _buildPlaybackButtons(),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          spacing: 5,
          children: [
            PlaylistLikeButton(
              playlistId: _resolvedArtistId,
              playlistData: () =>
                  artistPlaylistData(artistMap, songs: const []),
            ),
            PlaylistAddToPlaylistButton(resolvePlaylist: _loadCatalog),
            // Downloading artist = downloading all its songs
            PlaylistDownloadButton(
              playlistId: _resolvedArtistId,
              resolvePlaylist: _loadCatalog,
              songs: _catalog?['list'] as List?,
              requireSnapshotMatch: true,
            ),
            CupertinoButton(
              padding: const EdgeInsets.all(10),
              color: musynSecondarySurface(isDark),
              borderRadius: BorderRadius.circular(22),
              onPressed: _refresh,
              child: const Icon(
                CupertinoIcons.arrow_2_circlepath,
                size: 20,
                color: MusynStyle.appleRed,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// Play all artist songs (synced with "All songs" queue).
  Widget _buildPlaybackButtons() {
    return ValueListenableBuilder<bool>(
      valueListenable: _isLoadingCatalog,
      builder: (_, isLoading, __) => PlaylistActionButtons(
        isLoading: isLoading,
        onPlay: _playArtist,
        onShuffle: () => _playArtist(shuffle: true),
      ),
    );
  }

  Widget _buildTopSongsSection() {
    if (_topSongs.isEmpty) return const SizedBox.shrink();

    return Column(
      children: [
        const SizedBox(height: 24),
        SectionHeader(
          title: context.l10n.topSongs,
          icon: CupertinoIcons.music_note_2,
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: commonListViewBottomPadding,
          itemCount: _topSongs.length,
          itemBuilder: (context, index) => SongTile(
            song: _topSongs[index],
            key: ValueKey('artist_top_${_topSongs[index]['ytid']}_$index'),
            onTap: () {
              HapticFeedback.selectionClick();
              audioHandler.playPlaylistSong(
                playlist: {'title': _artistTitle, 'list': _topSongs},
                songIndex: index,
              );
            },
          ),
        ),
      ],
    );
  }

  String _releaseSubtitle(Map<String, dynamic> release) {
    final year = release['year']?.toString();
    final type = switch (release['releaseType']?.toString()) {
      'single' => context.l10n.single,
      'ep' => 'EP',
      _ => context.l10n.album,
    };
    return year == null || year.isEmpty ? type : '$type • $year';
  }

  // Shares the complete catalog with "All songs" and keeps it after the first
  // action so play, add and download cannot resolve different song snapshots.
  Future<Map?> _loadCatalog() async {
    final loadedCatalog = _catalog;
    if (loadedCatalog != null) return loadedCatalog;

    final inFlight = _catalogFuture;
    if (inFlight != null) return inFlight;

    final generation = _artistLoadGeneration;
    final artistId = _resolvedArtistId;
    final future = _resolveCatalog().timeout(const Duration(seconds: 20));
    _catalogFuture = future;
    final Map? catalog;
    try {
      catalog = await future;
    } catch (_) {
      if (identical(_catalogFuture, future)) _catalogFuture = null;
      rethrow;
    }

    final ownsFuture = identical(_catalogFuture, future);
    final isCurrent =
        mounted &&
        generation == _artistLoadGeneration &&
        artistId == _resolvedArtistId &&
        ownsFuture;
    if (ownsFuture) _catalogFuture = null;
    if (!isCurrent) return null;

    if (catalog != null && catalog['catalogStatus'] != 'failed') {
      setState(() {
        _catalog = Map<String, dynamic>.from(catalog!);
      });
    }
    return catalog;
  }

  Future<Map?> _resolveCatalog() {
    final artist = _artist;
    if (artist != null) return getArtistCatalogFromProfile(artist);

    return getPlaylistInfoForWidget(
      _resolvedArtistId,
      isArtist: true,
      artistName: _artistTitle,
      artistImage: _artist?['image']?.toString(),
      preferredVerified: _artist?['isVerifiedArtist'] == true,
    );
  }

  Future<void> _playArtist({bool shuffle = false}) async {
    _isLoadingCatalog.value = true;
    try {
      final catalog = await _loadCatalog();
      if (!mounted) return;

      final songs = catalog?['list'] as List? ?? const [];
      if (songs.isEmpty) {
        showToast(context, context.l10n.error);
        return;
      }

      if (shuffle) {
        await audioHandler.addPlaylistToQueue(
          List<Map>.from(songs.whereType<Map>())..shuffle(),
          replace: true,
          startIndex: 0,
          resetShuffle: false,
        );
      } else {
        await audioHandler.playPlaylistSong(playlist: catalog, songIndex: 0);
      }
    } catch (_) {
      if (mounted)
        showToast(context, 'Artist tracks could not be loaded. Try again.');
    } finally {
      if (mounted) _isLoadingCatalog.value = false;
    }
  }

  void _openArtist(Map<String, dynamic> artist) {
    final artistId = artist['ytid']?.toString();
    if (artistId == null || artistId.isEmpty) return;

    context.push(NavigationPaths.artistPath(context, artistId), extra: artist);
  }

  void _openRelease(Map<String, dynamic> release) {
    final releaseId = release['ytid']?.toString();
    if (releaseId == null || releaseId.isEmpty) return;

    context.push(NavigationPaths.albumPath(context, releaseId), extra: release);
  }
}
