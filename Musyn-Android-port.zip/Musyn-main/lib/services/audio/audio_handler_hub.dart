import 'package:musyn/services/audio/audio_preload_cache.dart';
import 'package:musyn/services/audio/audio_preload_service.dart';
import 'package:musyn/services/audio/audio_queue_controller.dart';
import 'package:musyn/services/audio/audio_queue_state.dart';

/// Single composition root for the audio subsystem.
///
/// Leaf modules only depend on their own data ([AudioQueueState],
/// [AudioPreloadCache]) or pure utilities. They never import each other.
/// `MusynAudioHandler` orchestrates via this hub only.
class AudioHandlerHub {
  AudioHandlerHub({
    this.queueLookahead = defaultQueueLookahead,
    this.maxConcurrentPreloads = defaultMaxConcurrentPreloads,
    this.fetchUrl,
  });

  /// Warm URLs for the next several tracks so lock-screen auto-advance and
  /// rapid skipping always land on a pre-resolved URL. iOS suspends the app
  /// during any silence gap between tracks, so cold-fetching is fatal.
  static const int defaultQueueLookahead = 3;
  static const int defaultMaxConcurrentPreloads = 2;

  final Future<String?> Function(Map)? fetchUrl;
  final int queueLookahead;
  final int maxConcurrentPreloads;

  final AudioQueueState queue = AudioQueueState();
  final AudioPreloadCache preloadCache = AudioPreloadCache();

  late final AudioQueueController queueOps = AudioQueueController(queue);
  late final AudioPreloadService preload = AudioPreloadService(
    cache: preloadCache,
    fetchUrl: fetchUrl,
    lookahead: queueLookahead,
    maxConcurrent: maxConcurrentPreloads,
  );

  /// Fast path: ytids currently in the play queue.
  Set<String> activeQueueYtids() => preload.queueYtids(queue.items);

  void cleanupStalePreloads() {
    preload.cleanupStaleForYtids(activeQueueYtids());
  }

  List<Map> upcomingPreloadCandidates({required bool offlineModeEnabled}) {
    return preload.upcomingSongs(
      queueItems: queue.items,
      currentIndex: queue.currentIndex,
      offlineModeEnabled: offlineModeEnabled,
    );
  }

  void resetPreloads() => preloadCache.reset();
}
