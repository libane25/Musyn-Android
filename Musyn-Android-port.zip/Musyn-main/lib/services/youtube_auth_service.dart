// ignore_for_file: cascade_invocations

import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:musyn/services/logger_service.dart';
import 'package:musyn/services/youtube_public_context.dart';
import 'package:webview_flutter/webview_flutter.dart';

class YouTubeAuthService {
  factory YouTubeAuthService() => _instance;

  YouTubeAuthService._internal();
  static final YouTubeAuthService _instance = YouTubeAuthService._internal();

  final isSignedIn = ValueNotifier<bool>(false);
  final userName = ValueNotifier<String?>(null);
  final userEmail = ValueNotifier<String?>(null);
  final userAvatarUrl = ValueNotifier<String?>(null);

  Map<String, String> getAuthHeaders() {
    try {
      if (!Hive.isBoxOpen('youtube_auth')) return {};
      final cookies = Hive.box('youtube_auth').get('cookies');
      if (cookies == null || cookies is! Map) return {};

      final typedCookies = Map<String, String>.from(cookies);

      final cookieString = typedCookies.entries
          .map((e) => '${e.key}=${e.value}')
          .join('; ');

      final sapisid = typedCookies['SAPISID'] ?? '';
      final secure1p = typedCookies['__Secure-1PAPISID'] ?? sapisid;
      final secure3p = typedCookies['__Secure-3PAPISID'] ?? sapisid;
      final primary = sapisid.isNotEmpty
          ? sapisid
          : (secure3p.isNotEmpty ? secure3p : secure1p);
      if (primary.isEmpty) return {};

      const origin = 'https://music.youtube.com';
      final timestamp = (DateTime.now().millisecondsSinceEpoch ~/ 1000)
          .toString();
      String hash(String token) =>
          '${timestamp}_${sha1.convert(utf8.encode('$timestamp $token $origin'))}';
      final authHeader =
          'SAPISIDHASH ${hash(primary)} '
          'SAPISID1PHASH ${hash(secure1p.isEmpty ? primary : secure1p)} '
          'SAPISID3PHASH ${hash(secure3p.isEmpty ? primary : secure3p)}';

      return {
        'Cookie': cookieString,
        'Authorization': authHeader,
        'Origin': origin,
        'X-Goog-AuthUser': '0',
      };
    } catch (e) {
      logger.log('Error generating auth headers: $e');
      return {};
    }
  }

  Future<void> saveCookies(Map<String, String> cookies) async {
    try {
      if (!Hive.isBoxOpen('youtube_auth')) {
        logger.log('youtube_auth box is not open');
        return;
      }

      final hasRequired =
          cookies.containsKey('SAPISID') ||
          cookies.containsKey('__Secure-3PAPISID');
      if (!hasRequired) {
        logger.log('Missing SAPISID or __Secure-3PAPISID cookie');
        return;
      }

      final box = Hive.box('youtube_auth');
      await box.put('cookies', cookies);
      isSignedIn.value = true;
      unawaited(fetchUserProfile());
    } catch (e) {
      logger.log('Error saving cookies: $e');
    }
  }

  void restoreSession() {
    try {
      if (!Hive.isBoxOpen('youtube_auth')) {
        return;
      }

      final box = Hive.box('youtube_auth');
      final cookies = box.get('cookies');

      if (cookies != null && cookies is Map) {
        final typedCookies = Map<String, String>.from(cookies);
        if (typedCookies.containsKey('SAPISID') ||
            typedCookies.containsKey('__Secure-3PAPISID')) {
          isSignedIn.value = true;
          unawaited(fetchUserProfile());
          return;
        }
      }

      isSignedIn.value = false;
    } catch (e) {
      logger.log('Error restoring session: $e');
      isSignedIn.value = false;
    }
  }

  void signOut() {
    try {
      if (Hive.isBoxOpen('youtube_auth')) {
        Hive.box('youtube_auth').clear();
      }
      isSignedIn.value = false;
      userName.value = null;
      userEmail.value = null;
      userAvatarUrl.value = null;
      unawaited(_clearWebViewCookies());
    } catch (e) {
      logger.log('Error signing out: $e');
    }
  }

  Future<void> _clearWebViewCookies() async {
    try {
      await WebViewCookieManager().clearCookies();
    } catch (e) {
      logger.log('Error clearing webview cookies: $e');
    }
  }

  Future<void> fetchUserProfile() async {
    if (!isSignedIn.value) return;

    try {
      final headers = getAuthHeaders();
      if (headers.isEmpty) return;

      headers['Content-Type'] = 'application/json';
      headers['User-Agent'] = YouTubePublicContext.userAgent;
      headers['Referer'] = 'https://music.youtube.com/';
      headers['X-Origin'] = 'https://music.youtube.com';
      final version = await YouTubePublicContext().version();

      final body = jsonEncode({
        'context': {
          'client': {
            'clientName': 'WEB_REMIX',
            'clientVersion': version,
            'hl': 'en',
          },
        },
      });

      final response = await http.post(
        Uri.parse('https://music.youtube.com/youtubei/v1/account/account_menu'),
        headers: headers,
        body: body,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        final actions = data['actions'] as List?;
        if (actions != null && actions.isNotEmpty) {
          final firstAction = actions.first as Map?;
          final openPopupAction = firstAction?['openPopupAction'] as Map?;
          final popup = openPopupAction?['popup'] as Map?;
          final multiPageMenuRenderer = popup?['multiPageMenuRenderer'] as Map?;
          final header = multiPageMenuRenderer?['header'] as Map?;
          final activeAccountHeaderRenderer =
              header?['activeAccountHeaderRenderer'] as Map?;

          if (activeAccountHeaderRenderer != null) {
            final accountName =
                activeAccountHeaderRenderer['accountName'] as Map?;
            final simpleText = accountName?['simpleText'] as String?;
            if (simpleText != null) {
              userName.value = simpleText;
            }

            final emailMap = activeAccountHeaderRenderer['email'] as Map?;
            final emailText = emailMap?['simpleText'] as String?;
            if (emailText != null) {
              userEmail.value = emailText;
            }

            final accountPhoto =
                activeAccountHeaderRenderer['accountPhoto'] as Map?;
            final thumbnails = accountPhoto?['thumbnails'] as List?;
            if (thumbnails != null && thumbnails.isNotEmpty) {
              final lastThumbnail = thumbnails.last as Map?;
              final url = lastThumbnail?['url'] as String?;
              if (url != null) {
                userAvatarUrl.value = url;
              }
            }
          }
        }
      } else {
        logger.log('Failed to fetch profile: ${response.statusCode}');
      }
    } catch (e) {
      logger.log('Error fetching profile: $e');
    }
  }
}
