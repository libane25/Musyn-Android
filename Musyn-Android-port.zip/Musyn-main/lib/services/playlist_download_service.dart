// ignore_for_file: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member

import 'dart:async';
import 'dart:collection';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:musyn/extensions/l10n.dart';
import 'package:musyn/services/common_services.dart';
import 'package:musyn/services/data_manager.dart';
import 'package:musyn/services/download_transfer.dart';
import 'package:musyn/services/io_service.dart';
import 'package:musyn/services/logger_service.dart';
import 'package:musyn/services/offline_playlist_registry.dart';
import 'package:musyn/services/settings_manager.dart';
import 'package:musyn/utilities/flutter_toast.dart';

class OfflinePlaylistService {
  factory OfflinePlaylistService() => _instance;
  OfflinePlaylistService._internal();
  static final OfflinePlaylistService _instance =
      OfflinePlaylistService._internal();

  // Playlist download state notifiers
  final Map<String, ValueNotifier<DownloadProgress>> downloadProgressNotifiers =
      {};
  final List<String> activeDownloads = [];
  final activeDownloadIds = ValueNotifier<List<String>>([]);
  final activeTitles = <String, String>{};
  void _publishActive() {
    activeDownloadIds.value = List.unmodifiable(activeDownloads);
  }

  ValueNotifier<List<dynamic>> get offlinePlaylists =>
      offlinePlaylistRegistry.offlinePlaylists;
  void reloadOfflinePlaylistsFromStorage() =>
      offlinePlaylistRegistry.reloadOfflinePlaylistsFromStorage();
  bool isPlaylistDownloaded(String id) =>
      offlinePlaylistRegistry.isPlaylistDownloaded(id);
  Map? getOfflinePlaylist(String id) =>
      offlinePlaylistRegistry.getOfflinePlaylist(id);
  void checkAndAutoMarkOffline(Map playlist) =>
      offlinePlaylistRegistry.checkAndAutoMarkOffline(playlist);

  ValueNotifier<DownloadProgress> getProgressNotifier(String playlistId) {
    return downloadProgressNotifiers.putIfAbsent(
      playlistId,
      () => _DownloadProgressNotifier(() => _releaseUnusedProgress(playlistId)),
    );
  }

  bool isPlaylistDownloading(String playlistId) {
    return activeDownloads.contains(playlistId);
  }

  Future<void> downloadPlaylist(BuildContext context, Map playlist) async {
    final playlistId = playlist['ytid'] as String? ?? playlist['title'];

    if (playlistId == null || playlistId.isEmpty) {
      showToast(context, context.l10n.error);
      return;
    }

    // Check if already downloading
    if (isPlaylistDownloading(playlistId)) {
      showToast(context, context.l10n.alreadyDownloading);
      return;
    }

    // Initialize download state
    final songsList = playlist['list'] as List<dynamic>? ?? [];
    if (songsList.isEmpty) {
      showToast(context, context.l10n.playlistEmpty);
      return;
    }

    // Set up progress tracking
    final progressNotifier = getProgressNotifier(playlistId)
      ..value = DownloadProgress(total: songsList.length);
    activeDownloads.add(playlistId);
    activeTitles[playlistId] = playlist['title']?.toString() ?? 'Playlist';
    _publishActive();

    try {
      final songQueue = Queue<dynamic>.from(songsList);
      const maxConcurrent = 3;
      final workerCount = songsList.length < maxConcurrent
          ? songsList.length
          : maxConcurrent;

      final batchSource = downloadSource.value;
      final batchQuality = downloadQuality.value;
      final workers = Future.wait([
        for (var i = 0; i < workerCount; i++)
          _processDownloadQueue(
            songQueue,
            progressNotifier,
            batchSource,
            batchQuality,
          ),
      ]);
      try {
        await workers.timeout(Duration(minutes: songsList.length * 2));
      } on TimeoutException {
        progressNotifier.value.isCancelled = true;
        progressNotifier.notifyListeners();
        // Cancellation closes active transfers. Do not reset shared progress
        // or permit another batch until the workers have actually stopped.
        await workers;
      }

      // Handle completion
      await _handleDownloadCompletion(
        context,
        playlistId,
        playlist,
        progressNotifier,
      );
    } catch (e, stackTrace) {
      logger.log(
        'Error during playlist download',
        error: e,
        stackTrace: stackTrace,
      );
      activeDownloads.remove(playlistId);
      activeTitles.remove(playlistId);
      _publishActive();
      cleanupProgressNotifier(playlistId);
      if (context.mounted) {
        showToast(context, '${context.l10n.error}: $e');
      }
    }
  }

  Future<void> _handleDownloadCompletion(
    BuildContext context,
    String playlistId,
    Map playlist,
    ValueNotifier<DownloadProgress> progressNotifier,
  ) async {
    try {
      // Remove from active downloads
      activeDownloads.remove(playlistId);
      activeTitles.remove(playlistId);
      _publishActive();

      final songsList = playlist['list'] as List<dynamic>;
      final completed = progressNotifier.value.completed;
      final failed = progressNotifier.value.failed;
      final total = songsList.length;
      // Count only files that actually exist and pass the playable size check.
      final playableCount = songsList.where((s) {
        final ytid = s is Map ? s['ytid']?.toString() : null;
        return hasPlayableOfflineFile(ytid);
      }).length;
      // Do not mark the playlist offline when many tracks failed or are
      // truncated stubs — require nearly-complete playable coverage.
      final mostlyComplete =
          !progressNotifier.value.isCancelled &&
          failed == 0 &&
          playableCount == total &&
          completed == total;

      // Only add to offline playlists if not cancelled and most songs succeeded
      if (mostlyComplete) {
        // Create an offline version of the playlist
        final offlinePlaylist = {
          ...playlist,
          'ytid': playlistId,
          'title': playlist['title'],
          'image': playlist['image'],
          'source': playlist['source'],
          'list': songsList,
          'downloadedAt': DateTime.now().millisecondsSinceEpoch,
        };

        // Add to offline playlists
        final updatedPlaylists = List<dynamic>.from(offlinePlaylists.value);

        final existingIndex = updatedPlaylists.indexWhere(
          (p) => p['ytid'] == playlistId,
        );

        if (existingIndex != -1) {
          updatedPlaylists[existingIndex] = offlinePlaylist;
        } else {
          updatedPlaylists.add(offlinePlaylist);
        }

        // Also mark albums/playlists whose songs are now fully offline
        final offlineSongIds = userOfflineSongs.value
            .map((s) => s['ytid'])
            .toSet();

        final seenIds = <String>{};
        final userPlaylistSources =
            <Map>[
              ...userCustomPlaylists.value,
              ...userLikedPlaylists.value,
              for (final folder in userPlaylistFolders.value)
                ...List<Map>.from(folder['playlists'] ?? []),
              ...playlists,
            ].where((p) {
              final id = p['ytid']?.toString();
              return id != null && seenIds.add(id);
            }).toList();
        for (final p in userPlaylistSources) {
          final pList = p['list'] as List?;
          if (pList == null ||
              pList.isEmpty ||
              p['ytid'] == playlistId ||
              isPlaylistDownloaded(p['ytid']?.toString() ?? '')) {
            continue;
          }
          if (pList.every((s) => offlineSongIds.contains(s['ytid']))) {
            updatedPlaylists.add({
              ...p,
              'list': pList,
              'downloadedAt': DateTime.now().millisecondsSinceEpoch,
            });
          }
        }

        offlinePlaylists.value = updatedPlaylists;
        unawaited(
          addOrUpdateData<List>(
            'userNoBackup',
            'offlinePlaylists',
            offlinePlaylists.value,
          ),
        );

        if (context.mounted) {
          showToast(
            context,
            '${context.l10n.playlistDownloaded}: ${progressNotifier.value.completed}/${songsList.length}',
          );
        }
      } else if (!progressNotifier.value.isCancelled) {
        // Cancelled toast is shown by cancelDownload, only show failure toast here.
        if (context.mounted) {
          showToast(
            context,
            '${context.l10n.downloadFailed}: ${progressNotifier.value.failed}/${songsList.length}',
          );
        }
      }

      // Clean up the progress notifier now that the download is fully done.
      cleanupProgressNotifier(playlistId);
    } catch (e, stackTrace) {
      logger.log(
        'Error handling download completion',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  Future<void> cancelDownload(BuildContext context, String playlistId) async {
    if (!isPlaylistDownloading(playlistId)) return;

    try {
      final progressNotifier = getProgressNotifier(playlistId);
      progressNotifier.value.isCancelled = true;
      progressNotifier.notifyListeners();

      // Immediate visual feedback
      showToast(context, context.l10n.cancellingDownload);

      const maxWaitTime = Duration(seconds: 30);
      final startTime = DateTime.now();

      // Wait for the ongoing tasks to complete with timeout
      while (activeDownloads.contains(playlistId)) {
        await Future.delayed(const Duration(milliseconds: 100));

        if (DateTime.now().difference(startTime) > maxWaitTime) {
          logger.log('Timeout waiting for download cancellation');
          throw TimeoutException(
            'Downloads are still stopping; retry shortly.',
          );
        }
      }

      showToast(context, context.l10n.downloadCancelled);
    } catch (e, stackTrace) {
      logger.log('Error cancelling download', error: e, stackTrace: stackTrace);
      if (context.mounted) showToast(context, 'Downloads are still stopping');
    }
  }

  Future<void> removeOfflinePlaylist(String playlistId) async {
    try {
      final normalizedPlaylistId = playlistId.trim();
      if (normalizedPlaylistId.isEmpty) {
        logger.log('Invalid playlistId for removal');
        return;
      }

      // Find the playlist
      final playlistIndex = offlinePlaylists.value.indexWhere(
        (playlist) =>
            playlist is Map &&
            playlist['ytid']?.toString() == normalizedPlaylistId,
      );

      if (playlistIndex == -1) {
        logger.log('Playlist not found for removal: $normalizedPlaylistId');
        return;
      }

      final playlist = offlinePlaylists.value[playlistIndex] as Map;

      // Get songs that are only in this playlist
      final songsInPlaylist = playlist['list'] as List<dynamic>? ?? [];
      final songIdsUsedElsewhere = _getSongIdsUsedElsewhere(
        normalizedPlaylistId,
      );

      for (final song in songsInPlaylist) {
        try {
          final songId = song['ytid'] as String?;

          if (songId == null || songId.isEmpty) {
            continue;
          }

          // Only remove if not used elsewhere.
          if (!songIdsUsedElsewhere.contains(songId)) {
            await removeSongFromOffline(songId);
          }
        } catch (e, stackTrace) {
          logger.log(
            'Error removing song from offline',
            error: e,
            stackTrace: stackTrace,
          );
        }
      }

      // Remove playlist from offline playlists
      final updatedPlaylists = List<dynamic>.from(offlinePlaylists.value)
        ..removeWhere(
          (p) => p is Map && p['ytid']?.toString() == normalizedPlaylistId,
        );
      offlinePlaylists.value = updatedPlaylists;
      unawaited(
        addOrUpdateData<List>(
          'userNoBackup',
          'offlinePlaylists',
          offlinePlaylists.value,
        ),
      );
    } catch (e, stackTrace) {
      logger.log(
        'Error removing offline playlist',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  /// Removes [songId] from offline storage and updates offline playlist flags.
  Future<bool> removeSongFromOfflineAndResync(String songId) async {
    final success = await removeSongFromOffline(songId);
    if (success) {
      unawaited(_resyncOfflinePlaylistFlags());
    }
    return success;
  }

  /// Removes stale entries from [offlinePlaylists].
  Future<void> _resyncOfflinePlaylistFlags() async {
    final current = offlinePlaylists.value;
    final stillFullyOffline = <dynamic>[];
    var changed = false;

    for (final playlist in current) {
      if (playlist is! Map) {
        stillFullyOffline.add(playlist);
        continue;
      }

      final songs = playlist['list'] as List<dynamic>? ?? [];
      if (isPlaylistFullyOffline(songs)) {
        stillFullyOffline.add(playlist);
      } else {
        changed = true;
        logger.log(
          'Dropping stale offline flag for playlist '
          '${playlist['ytid']}: no longer fully offline',
        );
      }
    }

    if (!changed) return;

    offlinePlaylists.value = stillFullyOffline;
    unawaited(
      addOrUpdateData<List>(
        'userNoBackup',
        'offlinePlaylists',
        offlinePlaylists.value,
      ),
    );
  }

  // Returns a set of song IDs that are used in other playlists or liked songs,
  Set<String> _getSongIdsUsedElsewhere(String excludedPlaylistId) {
    final songIds = <String>{
      for (final playlist in offlinePlaylists.value)
        if (playlist is Map &&
            playlist['ytid']?.toString() != excludedPlaylistId)
          for (final song in playlist['list'] as List<dynamic>? ?? [])
            if (song['ytid'] is String) song['ytid'] as String,
      for (final song in userLikedSongsList.value)
        if (song['ytid'] is String) song['ytid'] as String,
      for (final playlist in getUserCustomPlaylists())
        if (playlist['ytid']?.toString() != excludedPlaylistId)
          for (final song in playlist['list'] as List<dynamic>? ?? [])
            if (song['ytid'] is String) song['ytid'] as String,
    };

    return songIds;
  }

  Future<void> deleteAllDownloads() async {
    // Cancel all active downloads first and wait for them to stop
    final activeIds = List<String>.from(activeDownloads);
    for (final id in activeIds) {
      final notifier = downloadProgressNotifiers[id];
      if (notifier != null) {
        notifier.value.isCancelled = true;
        notifier.notifyListeners();
      }
    }

    const maxWaitTime = Duration(seconds: 30);
    final startTime = DateTime.now();
    while (activeDownloads.isNotEmpty) {
      if (DateTime.now().difference(startTime) > maxWaitTime) {
        logger.log('Timeout waiting for downloads to cancel before delete');
        throw TimeoutException(
          'Downloads are still stopping; retry deletion shortly.',
        );
      }
      await Future.delayed(const Duration(milliseconds: 100));
    }

    try {
      final tracksDir = Directory('$applicationDirPath/${FilePaths.tracksDir}');
      final artworksDir = Directory(
        '$applicationDirPath/${FilePaths.artworksDir}',
      );

      if (await tracksDir.exists()) {
        await tracksDir.delete(recursive: true);
      }
      if (await artworksDir.exists()) {
        await artworksDir.delete(recursive: true);
      }

      await FilePaths.ensureDirectoriesExist();

      userOfflineSongs.value = [];

      offlinePlaylists.value = [];

      for (final id in downloadProgressNotifiers.keys.toList()) {
        cleanupProgressNotifier(id);
      }
      activeDownloads.clear();
      activeTitles.clear();
      _publishActive();

      unawaited(addOrUpdateData<List>('userNoBackup', 'offlineSongs', []));
      unawaited(addOrUpdateData<List>('userNoBackup', 'offlinePlaylists', []));

      logger.log('All downloads deleted successfully');
    } catch (e, stackTrace) {
      logger.log(
        'Error deleting all downloads',
        error: e,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  void cleanupProgressNotifier(String playlistId) {
    try {
      if (downloadProgressNotifiers.containsKey(playlistId)) {
        final notifier = downloadProgressNotifiers[playlistId];
        notifier?.value = DownloadProgress(total: 0);
        _releaseUnusedProgress(playlistId);
      }
    } catch (e, stackTrace) {
      logger.log(
        'Error cleaning up progress notifier',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  void _releaseUnusedProgress(String playlistId) {
    final notifier = downloadProgressNotifiers[playlistId];
    if (notifier == null ||
        notifier.hasListeners ||
        isPlaylistDownloading(playlistId))
      return;
    downloadProgressNotifiers.remove(playlistId);
    notifier.dispose();
  }

  Future<void> _processDownloadQueue(
    Queue<dynamic> songQueue,
    ValueNotifier<DownloadProgress> progressNotifier,
    String source,
    String quality,
  ) async {
    while (songQueue.isNotEmpty && !progressNotifier.value.isCancelled) {
      final song = songQueue.removeFirst();

      try {
        if (song == null ||
            song['ytid'] == null ||
            song['ytid'].toString().isEmpty) {
          logger.log('Invalid song data in playlist download');
          progressNotifier.value.failed++;
          progressNotifier.notifyListeners();
          continue;
        }

        final success = await makeSongOffline(
          song,
          source: source,
          quality: quality,
          cancellation: progressNotifier.value.cancellation,
        );
        if (progressNotifier.value.isCancelled) break;
        if (success && hasPlayableOfflineFile(song['ytid']?.toString())) {
          final offlineSong = getOfflineSongByYtid(song['ytid']);
          song['audioPath'] = offlineSong['audioPath'];
          song['artworkPath'] = offlineSong['artworkPath'];
          progressNotifier.value.completed++;
        } else {
          progressNotifier.value.failed++;
        }
        progressNotifier.notifyListeners();
      } catch (e, stackTrace) {
        logger.log(
          'Failed to download song: ${song?['title']}',
          error: e,
          stackTrace: stackTrace,
        );
        progressNotifier.value.failed++;
        progressNotifier.notifyListeners();
      }
    }
  }
}

class _DownloadProgressNotifier extends ValueNotifier<DownloadProgress> {
  _DownloadProgressNotifier(this.onUnused) : super(DownloadProgress(total: 0));
  final VoidCallback onUnused;

  @override
  void removeListener(VoidCallback listener) {
    super.removeListener(listener);
    scheduleMicrotask(onUnused);
  }
}

class DownloadProgress {
  DownloadProgress({
    required this.total,
    this.completed = 0,
    this.failed = 0,
    bool isCancelled = false,
  }) {
    this.isCancelled = isCancelled;
  }

  final int total;
  int completed;
  int failed;
  final cancellation = DownloadCancellation();
  bool get isCancelled => cancellation.isCancelled;
  set isCancelled(bool value) {
    if (value) cancellation.cancel();
  }

  double get progress {
    if (total <= 0) return 0;
    final totalProcessed = completed + failed;
    return totalProcessed > total ? 1.0 : totalProcessed / total;
  }

  @override
  String toString() {
    final percentage = (progress * 100).toStringAsFixed(1);
    return '$percentage% ($completed/$total)';
  }
}

// Global instance for easy access
final offlinePlaylistService = OfflinePlaylistService();
