import 'package:audio_service/audio_service.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:musyn/models/playlist_sort_type.dart';
import 'package:musyn/services/provider_access.dart';
import 'package:musyn/utilities/language_utils.dart';

T _safeBoxGet<T>(String key, T defaultValue) {
  try {
    if (!Hive.isBoxOpen('settings')) return defaultValue;
    final v = Hive.box('settings').get(key, defaultValue: defaultValue);
    if (v is T) return v;
    // Handle nullable bool case where Hive returns null
    if (v == null && null is T) return v as T;
    return defaultValue;
  } catch (_) {
    return defaultValue;
  }
}

// Preferences - safely initialized even before Hive is open.
// After Hive opens, reloadSettingsFromStorage() restores persisted values.

final playNextSongAutomatically = ValueNotifier<bool>(
  _safeBoxGet<bool>('playNextSongAutomatically', true),
);

final useSystemColor = ValueNotifier<bool>(
  _safeBoxGet<bool>('useSystemColor', true),
);

final usePureBlackColor = ValueNotifier<bool>(
  _safeBoxGet<bool>('usePureBlackColor', false),
);

final offlineMode = ValueNotifier<bool>(
  _safeBoxGet<bool>('offlineMode', false),
);

final wrappedEnabled = ValueNotifier<bool>(false);
final sponsorBlockSupport = ValueNotifier<bool>(false);

final externalRecommendations = ValueNotifier<bool>(
  // Prefer YouTube-related recommendations for new installs. Existing users
  // retain their explicit setting from Hive.
  _safeBoxGet<bool>('externalRecommendations', true),
);

final audioQualitySetting = ValueNotifier<String>(
  _safeBoxGet<String>('audioQuality', 'high'),
);

final showAudioQualityBadge = ValueNotifier<bool>(
  _safeBoxGet<bool>('showAudioQualityBadge', true),
);

Locale languageSetting = getLocaleFromLanguageCode(
  _safeBoxGet<String>('languageCode', 'en'),
);

final themeModeSetting = ValueNotifier<int>(_safeBoxGet<int>('themeIndex', 0));

String playlistSortSetting = _safeBoxGet<String>(
  'playlistSortType',
  PlaylistSortType.default_.name,
);

String offlineSortSetting = _safeBoxGet<String>(
  'offlineSortType',
  OfflineSortType.default_.name,
);

Color primaryColorSetting = Color(_safeBoxGet<int>('accentColor', 0xff91cef4));

final shuffleNotifier = ValueNotifier<bool>(
  _safeBoxGet<bool>('shuffleEnabled', false),
);

final repeatNotifier = ValueNotifier<AudioServiceRepeatMode>(
  AudioServiceRepeatMode.values[_safeBoxGet<int>(
    'repeatMode',
    0,
  ).clamp(0, AudioServiceRepeatMode.values.length - 1)],
);

// Non-storage notifiers

var sleepTimerNotifier = ValueNotifier<Duration?>(null);

// Server-Notifiers

final announcementURL = ValueNotifier<String?>(null);

const chartCountries = {
  'IN': 'India',
  'ZZ': 'Global',
  'US': 'United States',
  'GB': 'United Kingdom',
};
final chartCountry = ValueNotifier<String>(
  _safeBoxGet<String>('chartCountry', 'IN'),
);

// JioSaavn settings
//
// These previously called `Hive.box('settings')` directly instead of going
// through `_safeBoxGet` like every other notifier in this file. That throws
// a HiveError ("Box not found") if anything reads `.value` before/while Hive
// finishes opening the settings box (or if Phase 1 in main.dart's
// initialisation() ever fails on a given device) - and `jiosaavnEnabled` in
// particular sits right in the song-resolution hot path (checked first, on
// every single song play, before falling back to YouTube), so a stray throw
// here silently kills playback for that call. Routed through the same safe
// helper as everything else for consistency.

final jiosaavnEnabled = ValueNotifier<bool>(
  _safeBoxGet<bool>('jiosaavnEnabled', false),
);

final jiosaavnQuality = ValueNotifier<String>(
  _safeBoxGet<String>('jiosaavnQuality', '320'),
);

final preferredSource = ValueNotifier<String>(
  _safeBoxGet<String>('preferredSource', 'auto'),
);

final downloadSource = ValueNotifier<String>(
  _safeBoxGet<String>('downloadSource', 'best'),
);

final downloadQuality = ValueNotifier<String>(
  _safeBoxGet<String>('downloadQuality', '320'),
);

// YouTube Music sync settings
final ytAutoSyncLikes = ValueNotifier<bool>(
  _safeBoxGet<bool>('ytAutoSyncLikes', true),
);

final ytAutoSyncPlaylists = ValueNotifier<bool>(
  _safeBoxGet<bool>('ytAutoSyncPlaylists', true),
);

final ytReportHistory = ValueNotifier<bool>(
  _safeBoxGet<bool>('ytReportHistory', true),
);

void reloadSettingsFromStorage() {
  final settings = Hive.box('settings');

  playNextSongAutomatically.value = settings.get(
    'playNextSongAutomatically',
    defaultValue: true,
  );
  useSystemColor.value = settings.get('useSystemColor', defaultValue: true);
  usePureBlackColor.value = settings.get(
    'usePureBlackColor',
    defaultValue: false,
  );
  offlineMode.value = settings.get('offlineMode', defaultValue: false);
  externalRecommendations.value = settings.get(
    'externalRecommendations',
    // Related YouTube recommendations are the default for new installs.
    // Hive still preserves an existing user's explicit preference.
    defaultValue: true,
  );
  audioQualitySetting.value = settings.get(
    'audioQuality',
    defaultValue: 'high',
  );
  showAudioQualityBadge.value = settings.get(
    'showAudioQualityBadge',
    defaultValue: true,
  );
  final restoredThemeIndex =
      settings.get('themeIndex') ?? settings.get('themeMode') ?? 0;
  if (restoredThemeIndex is int) themeModeSetting.value = restoredThemeIndex;

  final restoredLanguageCode = settings.get('languageCode', defaultValue: 'en');
  if (restoredLanguageCode is String) {
    languageSetting = getLocaleFromLanguageCode(restoredLanguageCode);
  }

  final restoredPlaylistSort = settings.get(
    'playlistSortType',
    defaultValue: PlaylistSortType.default_.name,
  );
  if (restoredPlaylistSort is String) {
    playlistSortSetting = restoredPlaylistSort;
  }

  final restoredOfflineSort = settings.get(
    'offlineSortType',
    defaultValue: OfflineSortType.default_.name,
  );
  if (restoredOfflineSort is String) {
    offlineSortSetting = restoredOfflineSort;
  }

  final restoredAccentColor = settings.get(
    'accentColor',
    defaultValue: 0xff91cef4,
  );
  if (restoredAccentColor is int) {
    primaryColorSetting = Color(restoredAccentColor);
  }

  shuffleNotifier.value = settings.get('shuffleEnabled', defaultValue: false);
  final restoredRepeatIndex = settings.get('repeatMode', defaultValue: 0);
  if (restoredRepeatIndex is int &&
      restoredRepeatIndex >= 0 &&
      restoredRepeatIndex < AudioServiceRepeatMode.values.length) {
    repeatNotifier.value = AudioServiceRepeatMode.values[restoredRepeatIndex];
  }

  jiosaavnEnabled.value = settings.get('jiosaavnEnabled', defaultValue: false);
  jiosaavnQuality.value = settings.get('jiosaavnQuality', defaultValue: '320');
  preferredSource.value = settings.get('preferredSource', defaultValue: 'auto');
  downloadSource.value = settings.get('downloadSource', defaultValue: 'best');
  downloadQuality.value = settings.get('downloadQuality', defaultValue: '320');
  final savedCountry = settings.get('chartCountry', defaultValue: 'IN');
  chartCountry.value = chartCountries.containsKey(savedCountry)
      ? savedCountry
      : 'IN';

  ytAutoSyncLikes.value = settings.get('ytAutoSyncLikes', defaultValue: true);
  ytAutoSyncPlaylists.value = settings.get(
    'ytAutoSyncPlaylists',
    defaultValue: true,
  );
  ytReportHistory.value = settings.get('ytReportHistory', defaultValue: true);
}

bool get jiosaavnAvailable =>
    jiosaavnEnabled.value && ProviderAccess.instance.configured;
