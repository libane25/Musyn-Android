import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:musyn/services/io_service.dart';
import 'package:musyn/services/local_music_catalog.dart';
import 'package:musyn/services/logger_service.dart';

/// Persisted library of songs the user imported from on-device files.
///
/// Files are copied into the app documents directory (`local_music/audio` and
/// `local_music/artwork`). The catalog is `local_music/library.json`. Copying
/// means playback does not need a lasting Storage Access Framework grant or
/// broad media permission. The Android picker lives in LocalMusicImporter.
class LocalMusicLibrary {
  LocalMusicLibrary._();

  static final LocalMusicLibrary instance = LocalMusicLibrary._();

  static const _channel = MethodChannel('com.vorynlabs.musyn/local_music');

  final ValueNotifier<List<Map<String, dynamic>>> tracks =
      ValueNotifier<List<Map<String, dynamic>>>([]);

  bool _loaded = false;

  Directory? get root {
    if (applicationDirPath.isEmpty) return null;
    return Directory('$applicationDirPath/local_music');
  }

  Future<void> load() async {
    final directory = root;
    if (directory == null) return;
    try {
      final file = File('${directory.path}/library.json');
      if (!await file.exists()) {
        tracks.value = [];
        _loaded = true;
        return;
      }
      final decoded = jsonDecode(await file.readAsString());
      final rawTracks = decoded is Map ? decoded['tracks'] : null;
      final loaded = <Map<String, dynamic>>[];
      if (rawTracks is List) {
        for (final item in rawTracks) {
          if (item is Map) {
            final song = Map<String, dynamic>.from(item);
            song['catalogOrigin'] = 'local';
            song['source'] = 'local';
            song['isOffline'] = true;
            song['forceSource'] = 'offline';
            song['resolvedSource'] = 'local';
            _rebase(song, directory);
            loaded.add(song);
          }
        }
      }
      tracks.value = loaded;
      _loaded = true;
    } catch (error, stack) {
      logger.log(
        'Local music library could not be read',
        error: error,
        stackTrace: stack,
      );
      tracks.value = [];
      _loaded = true;
    }
  }

  Future<LocalImportSummary> importFiles() => _import('importFiles');

  Future<LocalImportSummary> importFolder() => _import('importFolder');

  List<Map<String, dynamic>> search(String query) =>
      searchLocalTracks(tracks.value, query);

  List<String> suggestions(String query) =>
      localMusicSuggestions(tracks.value, query);

  Future<void> remove(String id) async {
    final current = tracks.value;
    Map<String, dynamic>? removed;
    final next = <Map<String, dynamic>>[];
    for (final song in current) {
      if (song['ytid']?.toString() == id && removed == null) {
        removed = song;
      } else {
        next.add(song);
      }
    }
    if (removed == null) return;
    tracks.value = next;
    await _persist();
    await _deleteFile(removed['audioPath']?.toString());
    await _deleteFile(removed['artworkPath']?.toString());
  }

  Future<int> removeMissing() async {
    final missing = tracks.value
        .where((song) => song['missing'] == true)
        .map((song) => song['ytid']?.toString() ?? '')
        .where((id) => id.isNotEmpty)
        .toList();
    for (final id in missing) {
      await remove(id);
    }
    return missing.length;
  }

  Future<LocalImportSummary> _import(String method) async {
    if (!_loaded) await load();
    final directory = root;
    if (directory == null) {
      return const LocalImportSummary(
        cancelled: false,
        added: 0,
        duplicates: 0,
        unsupported: 0,
        failed: 1,
        truncated: false,
      );
    }
    await directory.create(recursive: true);
    try {
      final raw = await _channel.invokeMethod<Object>(method, {
        'directory': directory.path,
      });
      final body = raw is Map ? raw : const <Object?, Object?>{};
      if (body['cancelled'] == true) {
        return const LocalImportSummary(
          cancelled: true,
          added: 0,
          duplicates: 0,
          unsupported: 0,
          failed: 0,
          truncated: false,
        );
      }
      final imported = body['imported'];
      final incoming = imported is List
          ? imported.whereType<Map>().toList()
          : <Map>[];
      final merge = mergeImportedTracks(tracks.value, incoming);
      for (final path in merge.pathsToDelete) {
        await _deleteFile(path);
      }
      tracks.value = merge.tracks;
      if (merge.added > 0) await _persist();
      int count(Object? value) =>
          value is int ? value : int.tryParse(value?.toString() ?? '') ?? 0;
      return LocalImportSummary(
        cancelled: false,
        added: merge.added,
        duplicates: count(body['duplicates']) + merge.duplicates,
        unsupported: count(body['unsupported']) + merge.rejected,
        failed: count(body['failed']),
        truncated: body['truncated'] == true,
      );
    } on MissingPluginException {
      return const LocalImportSummary(
        cancelled: false,
        added: 0,
        duplicates: 0,
        unsupported: 0,
        failed: 1,
        truncated: false,
      );
    } catch (error, stack) {
      logger.log('Local music import failed', error: error, stackTrace: stack);
      return const LocalImportSummary(
        cancelled: false,
        added: 0,
        duplicates: 0,
        unsupported: 0,
        failed: 1,
        truncated: false,
      );
    }
  }

  void _rebase(Map<String, dynamic> song, Directory directory) {
    song['audioPath'] = _existingPath(
      song['audioPath']?.toString(),
      Directory('${directory.path}/audio'),
    );
    song['artworkPath'] = _existingPath(
      song['artworkPath']?.toString(),
      Directory('${directory.path}/artwork'),
    );
    final audio = song['audioPath']?.toString() ?? '';
    song['missing'] = audio.isEmpty || !File(audio).existsSync();
  }

  String? _existingPath(String? stored, Directory folder) {
    if (stored == null || stored.isEmpty) return null;
    if (File(stored).existsSync()) return stored;
    final name = pathBaseName(stored);
    if (name.isEmpty) return stored;
    final candidate = File('${folder.path}/$name');
    if (candidate.existsSync()) return candidate.path;
    return stored;
  }

  Future<void> _persist() async {
    final directory = root;
    if (directory == null) return;
    await directory.create(recursive: true);
    final file = File('${directory.path}/library.json');
    final temp = File('${file.path}.tmp');
    final body = {
      'version': 1,
      'tracks': tracks.value,
    };
    await temp.writeAsString(jsonEncode(body));
    if (await file.exists()) await file.delete();
    await temp.rename(file.path);
  }

  Future<void> _deleteFile(String? path) async {
    if (path == null || path.isEmpty) return;
    final file = File(path);
    if (await file.exists()) {
      try {
        await file.delete();
      } catch (error) {
        logger.log('Could not delete imported file $path', error: error);
      }
    }
  }
}
