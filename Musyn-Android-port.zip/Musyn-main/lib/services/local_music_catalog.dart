/// Pure helpers for the imported-music library.
///
/// Audio bytes live in app-private storage. This file only shapes the
/// catalog records that point at those files.

const localAudioExtensions = {'mp3', 'm4a', 'aac', 'flac', 'wav', 'ogg'};

const localMusicCatalogLimit = 2000;

const searchCatalogYouTubeMusic = 'youtube_music';
const searchCatalogYouTube = 'youtube';
const searchCatalogLocal = 'local';

const searchCatalogValues = {
  searchCatalogYouTubeMusic,
  searchCatalogYouTube,
  searchCatalogLocal,
};

String searchCatalogLabel(String value) => switch (value) {
  searchCatalogYouTube => 'YouTube',
  searchCatalogLocal => 'Local Music',
  _ => 'YouTube Music',
};

bool isLocalCatalogSong(Map song) =>
    song['catalogOrigin'] == 'local' || song['source'] == 'local';

bool isYouTubeVideoSong(Map song) =>
    song['catalogOrigin'] == 'youtube_video' || song['source'] == 'youtube_video';

String pathBaseName(String name) {
  var cut = name.lastIndexOf('/');
  final backslash = name.lastIndexOf('\\');
  if (backslash > cut) cut = backslash;
  return (cut >= 0 ? name.substring(cut + 1) : name).trim();
}

String titleFromFileName(String name) {
  final base = pathBaseName(name);
  final dot = base.lastIndexOf('.');
  final stem = dot > 0 ? base.substring(0, dot) : base;
  final cleaned = stem
      .replaceAll(RegExp('[_]+'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  return cleaned.isEmpty ? 'Unknown Title' : cleaned;
}

String? _clean(Object? value) {
  final text = value?.toString().trim() ?? '';
  if (text.isEmpty || text == 'null') return null;
  return text;
}

/// Turns one imported file into a song map the player already understands.
///
/// Returns null when the file is missing a path or uses an unsupported type.
Map<String, dynamic>? localTrackFromImport(Map raw) {
  final audioPath = _clean(raw['audioPath']);
  final format = _clean(raw['format'])?.toLowerCase();
  final id = _clean(raw['id']) ?? _clean(raw['ytid']);
  if (audioPath == null || id == null || format == null) return null;
  if (!localAudioExtensions.contains(format)) return null;

  final fileName = _clean(raw['fileName']) ?? pathBaseName(audioPath);
  final durationRaw = raw['duration'];
  final duration = durationRaw is int
      ? durationRaw
      : int.tryParse(durationRaw?.toString() ?? '') ?? 0;

  return {
    'id': id,
    'ytid': id,
    'title': _clean(raw['title']) ?? titleFromFileName(fileName),
    'artist': _clean(raw['artist']) ?? 'Unknown Artist',
    'album': _clean(raw['album']),
    'duration': duration < 0 ? 0 : duration,
    'audioPath': audioPath,
    'artworkPath': _clean(raw['artworkPath']),
    'fileName': fileName,
    'contentHash': _clean(raw['contentHash']),
    'audioCodec': format,
    'catalogOrigin': 'local',
    'source': 'local',
    'resolvedSource': 'local',
    'isOffline': true,
    // Keeps a missing import from being looked up as a streaming track.
    'forceSource': 'offline',
    'missing': false,
  };
}

class LocalImportMerge {
  const LocalImportMerge({
    required this.tracks,
    required this.added,
    required this.duplicates,
    required this.rejected,
    required this.pathsToDelete,
  });

  final List<Map<String, dynamic>> tracks;
  final int added;
  final int duplicates;
  final int rejected;
  final List<String> pathsToDelete;
}

LocalImportMerge mergeImportedTracks(
  List<Map<String, dynamic>> existing,
  List<Map> incoming,
) {
  final tracks = existing.map(Map<String, dynamic>.from).toList();
  final hashes = <String>{
    for (final song in tracks)
      if (_clean(song['contentHash']) != null) song['contentHash'].toString(),
  };
  final ids = <String>{
    for (final song in tracks)
      if (_clean(song['ytid']) != null) song['ytid'].toString(),
  };
  final keptPaths = <String>{
    for (final song in tracks) ...[
      if (_clean(song['audioPath']) != null) song['audioPath'].toString(),
      if (_clean(song['artworkPath']) != null) song['artworkPath'].toString(),
    ],
  };
  var added = 0;
  var duplicates = 0;
  var rejected = 0;
  final pathsToDelete = <String>[];

  void release(Object? path) {
    final value = _clean(path);
    if (value == null || keptPaths.contains(value)) return;
    pathsToDelete.add(value);
  }

  for (final raw in incoming) {
    final track = localTrackFromImport(raw);
    if (track == null) {
      rejected++;
      release(raw['audioPath']);
      release(raw['artworkPath']);
      continue;
    }
    final hash = track['contentHash']?.toString();
    final id = track['ytid'].toString();
    if (ids.contains(id) || (hash != null && hashes.contains(hash))) {
      duplicates++;
      release(track['audioPath']);
      release(track['artworkPath']);
      continue;
    }
    ids.add(id);
    if (hash != null) hashes.add(hash);
    keptPaths.add(track['audioPath'].toString());
    final artwork = track['artworkPath']?.toString();
    if (artwork != null) keptPaths.add(artwork);
    tracks.add(track);
    added++;
  }

  return LocalImportMerge(
    tracks: tracks,
    added: added,
    duplicates: duplicates,
    rejected: rejected,
    pathsToDelete: pathsToDelete,
  );
}

List<Map<String, dynamic>> searchLocalTracks(
  List<Map<String, dynamic>> tracks,
  String query,
) {
  final needle = query.trim().toLowerCase();
  if (needle.isEmpty) {
    return tracks.map(Map<String, dynamic>.from).toList();
  }
  return [
    for (final song in tracks)
      if (_matches(song, needle)) Map<String, dynamic>.from(song),
  ];
}

bool _matches(Map song, String needle) {
  final haystack = [
    song['title'],
    song['artist'],
    song['album'],
    song['fileName'],
  ].whereType<Object>().join(' ').toLowerCase();
  return haystack.contains(needle);
}

List<String> localMusicSuggestions(
  List<Map<String, dynamic>> tracks,
  String query, {
  int limit = 8,
}) {
  final needle = query.trim().toLowerCase();
  if (needle.isEmpty) return const [];
  final suggestions = <String>[];
  for (final song in tracks) {
    for (final field in ['title', 'artist', 'album']) {
      final value = _clean(song[field]);
      if (value == null || value == 'Unknown Artist') continue;
      if (!value.toLowerCase().contains(needle)) continue;
      if (suggestions.contains(value)) continue;
      suggestions.add(value);
      if (suggestions.length >= limit) return suggestions;
    }
  }
  return suggestions;
}

class LocalImportSummary {
  const LocalImportSummary({
    required this.cancelled,
    required this.added,
    required this.duplicates,
    required this.unsupported,
    required this.failed,
    required this.truncated,
  });

  final bool cancelled;
  final int added;
  final int duplicates;
  final int unsupported;
  final int failed;
  final bool truncated;

  bool get hasChanges => added > 0;

  String get message {
    if (cancelled) return '';
    if (added == 0 && duplicates == 0 && unsupported == 0 && failed == 0) {
      return 'No supported audio files were selected.';
    }
    final parts = <String>[
      if (added > 0) 'Imported $added ${added == 1 ? 'song' : 'songs'}',
      if (duplicates > 0)
        '$duplicates ${duplicates == 1 ? 'duplicate was' : 'duplicates were'} skipped',
      if (unsupported > 0)
        '$unsupported unsupported ${unsupported == 1 ? 'file was' : 'files were'} skipped',
      if (failed > 0)
        '$failed ${failed == 1 ? 'file' : 'files'} could not be copied',
      if (truncated) 'Stopped after $localMusicCatalogLimit files',
    ];
    return '${parts.join('. ')}.';
  }
}

String formatLocalDuration(Object? duration) {
  final seconds = duration is int
      ? duration
      : int.tryParse(duration?.toString() ?? '');
  if (seconds == null || seconds <= 0) return '—';
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remain = seconds % 60;
  if (hours > 0) {
    return '$hours:${minutes.toString().padLeft(2, '0')}:${remain.toString().padLeft(2, '0')}';
  }
  return '$minutes:${remain.toString().padLeft(2, '0')}';
}
