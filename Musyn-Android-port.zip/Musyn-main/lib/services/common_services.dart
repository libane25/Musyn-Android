import 'dart:async';
import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:musyn/constants/clients.dart';
import 'package:musyn/services/artist_service.dart' show ytMusicClient;
import 'package:musyn/services/audio/player_artwork_cache.dart';
import 'package:musyn/services/audio/stream_resolution_pool.dart';
import 'package:musyn/services/data_manager.dart';
import 'package:musyn/services/download_activity.dart';
import 'package:musyn/services/download_source_policy.dart';
import 'package:musyn/services/download_transfer.dart';
import 'package:musyn/services/io_service.dart';
import 'package:musyn/services/library_state.dart';
import 'package:musyn/services/logger_service.dart';
import 'package:musyn/services/lyrics_manager.dart';
import 'package:musyn/services/lyrics_request_cache.dart';
import 'package:musyn/services/offline_song_registry.dart';
import 'package:musyn/services/settings_manager.dart';
import 'package:musyn/services/source_resolver.dart';
import 'package:musyn/services/stream_url_probe.dart';
import 'package:musyn/services/youtube_auth_service.dart';
import 'package:musyn/services/youtube_backoff.dart';
import 'package:musyn/services/youtube_client.dart';
import 'package:musyn/services/youtube_music_sync_service.dart';
import 'package:musyn/services/ytdlp_client_sync_service.dart';
import 'package:musyn/utilities/app_utils.dart';
import 'package:musyn/utilities/artwork_provider.dart' show upgradeArtworkUrl;
import 'package:musyn/utilities/async_operation_queue.dart';
import 'package:musyn/utilities/flutter_toast.dart';
import 'package:musyn/utilities/formatter.dart';
import 'package:musyn/utilities/track_matcher.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

export 'package:musyn/services/library_state.dart';

List? _likedSongIdsSnapshot;
final Set<String> _likedSongIdsSet = {
  ...userLikedSongsList.value
      .map((s) => s['ytid']?.toString() ?? '')
      .where((id) => id.isNotEmpty),
};
List? _offlineSongIdsSnapshot;
final Set<String> _offlineSongIdsSet = {
  ...userOfflineSongs.value
      .map((s) => s['ytid']?.toString() ?? '')
      .where((id) => id.isNotEmpty),
};

void _syncLikedSongIdsSet() {
  _likedSongIdsSnapshot = userLikedSongsList.value;
  _likedSongIdsSet
    ..clear()
    ..addAll(
      userLikedSongsList.value
          .map((s) => s['ytid']?.toString() ?? '')
          .where((id) => id.isNotEmpty),
    );
}

void _syncOfflineSongIdsSet() {
  _offlineSongIdsSnapshot = userOfflineSongs.value;
  _offlineSongIdsSet
    ..clear()
    ..addAll(
      userOfflineSongs.value
          .map((s) => s['ytid']?.toString() ?? '')
          .where((id) => id.isNotEmpty),
    );
}

dynamic nextRecommendedSong;

var _songLikeUpdateToken = 0;
final _latestSongLikeUpdateTokens = <String, int>{};
const _maxSongLikeTokenEntries = 200;

final lyrics = ValueNotifier<String?>(null);
String? lastFetchedLyrics;

void reloadSongLibraryStateFromStorage() {
  try {
    if (Hive.isBoxOpen('user')) {
      final userBox = Hive.box('user');
      userLikedSongsList.value = List.from(
        userBox.get('likedSongs', defaultValue: []),
      );
      userRecentlyPlayed.value = List.from(
        userBox.get('recentlyPlayedSongs', defaultValue: []),
      );
      _syncLikedSongIdsSet();
    }
    if (Hive.isBoxOpen('userNoBackup')) {
      final box = Hive.box('userNoBackup');
      userOfflineSongs.value = List.from(
        box.get('offlineSongs', defaultValue: []),
      );
      _syncOfflineSongIdsSet();
    }
  } catch (e) {
    logger.log('Error reloading song library state: $e');
  }
}

// Timeouts and durations used across manifest fetching and cache validation.
const Duration _cacheValidationDuration = songCacheDuration;
const Duration _headRevalidateAge = Duration(minutes: 30);

final youtubeStreamBackoff = YoutubeBackoff();

String? _pendingYoutubeStreamError;

void setYoutubeStreamError(String message) {
  _pendingYoutubeStreamError = message;
}

String? consumeYoutubeStreamError() {
  final message = _pendingYoutubeStreamError;
  _pendingYoutubeStreamError = null;
  return message;
}

String _youtubeStreamFailureMessage() {
  if (youtubeStreamBackoff.active)
    return 'YouTube is temporarily limiting requests. Wait a moment, then retry this song.';
  final label = YtdlpClientSyncService.instance.clientLabel;
  return "Couldn't load YouTube stream ($label). "
      'Try Sync YouTube Client in Settings.';
}

String _songStreamCacheKey(String songId, String source) =>
    'song_${songId}_${audioQualitySetting.value}_${source}_url';

String _songStreamCacheMetaKey(String songId, String source) =>
    '${_songStreamCacheKey(songId, source)}_meta';

Future<void> _cacheResolvedStream(
  String songId,
  String source,
  String url,
  Map<String, dynamic> metadata,
) async {
  final key = _songStreamCacheKey(songId, source);
  final metaKey = _songStreamCacheMetaKey(songId, source);
  final now = DateTime.now();
  // Atomic URL + metadata write so cache hits never lack provenance.
  await addOrUpdateData<String>('cache', key, url);
  final cacheBox = await Hive.openBox('cache');
  await cacheBox.putAll({
    _songStreamCacheMetaKey(songId, source): {'source': source, ...metadata},
    '${metaKey}_date': now,
    '${key}_date': now,
  });
}

bool _isCachedHeAacYoutube(Map metadata) {
  final itag = metadata['itag'];
  if (itag is int && kHeAacItags.contains(itag)) return true;
  final parsedItag = int.tryParse(itag?.toString() ?? '');
  if (parsedItag != null && kHeAacItags.contains(parsedItag)) return true;
  return isHeAacFormatLabel(metadata['format']?.toString());
}

/// Fills `song['duration']` from YouTube catalog when Innertube/search omitted it.
/// Needed so iOS can clip HE-AAC/SBR streams to the real track length.
Future<void> ensureYoutubeCatalogDuration(Map song) async {
  if (parseSongDuration(song['duration']) != null) return;
  final source =
      song['resolvedSource']?.toString() ?? song['source']?.toString();
  if (source == 'jiosaavn' || source == 'saavn') return;
  final songId = song['ytid']?.toString();
  if (songId == null || songId.isEmpty) return;
  try {
    final video = await ytClient.videos
        .get(songId)
        .timeout(const Duration(seconds: 4));
    final seconds = video.duration?.inSeconds;
    if (seconds != null && seconds > 0) {
      song['duration'] = seconds;
      logger.log('Fetched YouTube catalog duration for $songId: ${seconds}s');
    }
  } catch (e) {
    logger.log('Could not fetch catalog duration for $songId: $e');
  }
}

/// Fetches a stream manifest for a song via direct InnerTube connection.
String? _youtubeClientUserAgent(YoutubeApiClient client) {
  final clientContext = client.payload['context']?['client'];
  return clientContext is Map ? clientContext['userAgent']?.toString() : null;
}

Future<({StreamManifest manifest, YoutubeApiClient? client})?> _tryGetManifest(
  String songId, {
  required String attempt,
  required YoutubeExplode requestClient,
  required Duration timeout,
  List<YoutubeApiClient>? ytClients,
}) async {
  try {
    final manifest = await requestClient.videos.streams
        .getManifest(songId, ytClients: ytClients)
        .timeout(timeout);
    if (manifest.audioOnly.isNotEmpty) {
      logger.log('YouTube manifest via $attempt for $songId');
      return (
        manifest: manifest,
        client: ytClients == null || ytClients.isEmpty ? null : ytClients.first,
      );
    }
    logger.log(
      'YouTube manifest via $attempt for $songId had no audio streams',
    );
  } catch (error) {
    if (error is RequestLimitExceededException) {
      youtubeStreamBackoff.limited();
      setYoutubeStreamError(_youtubeStreamFailureMessage());
      rethrow;
    }
    logger.log('$attempt getManifest failed for $songId: $error');
  }
  return null;
}

Future<({StreamManifest manifest, YoutubeApiClient? client})?>
_fetchStreamManifest(String songId) async {
  if (youtubeStreamBackoff.active) return null;
  // A manifest owns its transport. Closing it aborts SDK retries left behind
  // by a timeout, without closing unrelated playback/catalogue requests.
  final requestClient = YoutubeExplode();
  final clock = Stopwatch()..start();
  try {
    for (final client in youtubeStreamClients()) {
      if (youtubeStreamBackoff.active) return null;
      final remaining = const Duration(seconds: 12) - clock.elapsed;
      if (remaining <= Duration.zero) return null;
      final name =
          client.payload['context']?['client']?['clientName']?.toString() ??
          'unknown';
      final result = await _tryGetManifest(
        songId,
        attempt: name,
        requestClient: requestClient,
        timeout: remaining > const Duration(seconds: 6)
            ? const Duration(seconds: 6)
            : remaining,
        ytClients: [client],
      );
      if (result != null) return (manifest: result.manifest, client: client);
    }
    return null;
  } finally {
    requestClient.close();
  }
}

DateTime? _parseCacheTimestamp(dynamic raw) {
  if (raw is DateTime) return raw;
  if (raw is int) return DateTime.fromMillisecondsSinceEpoch(raw);
  if (raw is String) return DateTime.tryParse(raw);
  return null;
}

/// Returns a cached song URL if present and still valid.
Future<String?> _getCachedSongUrl(
  String cacheKey,
  Duration cacheDuration, {
  String? userAgent,
}) async {
  final cacheBox = await Hive.openBox('cache');
  final cachedAt = _parseCacheTimestamp(await cacheBox.get('${cacheKey}_date'));

  final cachedUrl = await getData(
    'cache',
    cacheKey,
    cachingDuration: cacheDuration,
  );

  if (cachedUrl is! String || cachedUrl.isEmpty) {
    return null;
  }

  final parsed = Uri.tryParse(cachedUrl);
  if (parsed == null || !isPlayableYoutubeStreamUrl(parsed)) {
    logger.log('Cached stream URL invalid for $cacheKey');
    await deleteData('cache', cacheKey);
    await deleteData('cache', '${cacheKey}_meta');
    return null;
  }

  if (cachedAt != null &&
      DateTime.now().difference(cachedAt) > _headRevalidateAge) {
    if (!await isStreamUrlAlive(cachedUrl, userAgent: userAgent)) {
      logger.log('Stale cached stream URL rejected for $cacheKey');
      await deleteData('cache', cacheKey);
      await deleteData('cache', '${cacheKey}_meta');
      return null;
    }
  } else if (cachedAt == null) {
    // Legacy entries without a stored date must be probed once.
    if (!await isStreamUrlAlive(cachedUrl, userAgent: userAgent)) {
      logger.log('Untimestamped cached stream URL rejected for $cacheKey');
      await deleteData('cache', cacheKey);
      await deleteData('cache', '${cacheKey}_meta');
      return null;
    }
  }

  return cachedUrl;
}

Future<List> fetchSongsList(String searchQuery) async {
  try {
    // YouTube Music catalog with Songs filter (not generic video search).
    final musicTracks = await ytMusicClient.music.searchSongs(searchQuery);
    if (musicTracks.isNotEmpty) {
      return musicTracks
          .map((video) {
            final layout = returnSongLayout(0, video);
            layout['catalogOrigin'] = 'youtube';
            return layout;
          })
          .where(_isMusicSearchResult)
          .toList();
    }

    // Soft fallback only when YTM songs shelf is empty — filter hard.
    final List<Video> searchResults = await ytClient.search.search(
      '$searchQuery audio',
    );
    return searchResults
        .map((video) {
          final layout = returnSongLayout(0, video);
          // Fallback hits are regular YouTube videos, not YouTube Music songs.
          layout['catalogOrigin'] = 'youtube_video';
          layout['source'] = 'youtube_video';
          return layout;
        })
        .where(_isGenericVideoMusicResult)
        .toList();
  } catch (e, stackTrace) {
    logger.log('Error in fetchSongsList', error: e, stackTrace: stackTrace);
    return [];
  }
}

/// Lenient filter for YouTube Music Songs shelf results.
/// YTM's searchSongs endpoint only returns songs, so we trust the source
/// and don't reject results with missing duration (which is common for YTM
/// Video objects where duration isn't populated).
bool _isMusicSearchResult(Map layout) {
  final title = layout['title']?.toString().trim() ?? '';
  final artist = layout['artist']?.toString().trim() ?? '';
  if (title.isEmpty || artist.isEmpty) return false;
  final lower = '$title $artist'.toLowerCase();
  if (lower.contains('trailer') ||
      lower.contains('teaser') ||
      lower.contains('behind the scenes') ||
      lower.contains('interview') ||
      lower.contains('reaction')) {
    return false;
  }
  // If duration IS available, still cap at 15 min.
  final duration = layout['duration'];
  final seconds = duration is int
      ? duration
      : int.tryParse(duration?.toString() ?? '');
  if (seconds != null && seconds > 900) return false;
  return true;
}

/// Strict filter for generic YouTube video search fallback.
/// Requires valid duration to block podcasts, lectures, non-music videos.
bool _isGenericVideoMusicResult(Map layout) {
  final title = layout['title']?.toString().trim() ?? '';
  final artist = layout['artist']?.toString().trim() ?? '';
  if (title.isEmpty || artist.isEmpty) return false;
  final duration = layout['duration'];
  final seconds = duration is int
      ? duration
      : int.tryParse(duration?.toString() ?? '');
  if (seconds == null || seconds <= 0) return false;
  final lower = '$title $artist'.toLowerCase();
  if (lower.contains('trailer') ||
      lower.contains('teaser') ||
      lower.contains('behind the scenes') ||
      lower.contains('interview') ||
      lower.contains('reaction')) {
    return false;
  }
  if (seconds > 900) return false;
  return true;
}

/// Regular YouTube search. Playback still uses the existing audio resolver.
///
/// Results stay tagged `youtube_video` so they are not mixed into the
/// YouTube Music catalog. If YouTube will not play a video, the existing
/// playback error path reports it. This does not add a separate downloader
/// or bypass playback limits.
Future<List> fetchYouTubeVideos(String searchQuery) async {
  try {
    final List<Video> searchResults = await ytClient.search.search(searchQuery);
    return searchResults
        .map((video) {
          final layout = returnSongLayout(0, video);
          layout['catalogOrigin'] = 'youtube_video';
          layout['source'] = 'youtube_video';
          layout['forceSource'] = 'youtube';
          return layout;
        })
        .where(_isYouTubeVideoResult)
        .toList();
  } catch (e, stackTrace) {
    logger.log('Error in fetchYouTubeVideos', error: e, stackTrace: stackTrace);
    return [];
  }
}

bool _isYouTubeVideoResult(Map layout) {
  final title = layout['title']?.toString().trim() ?? '';
  if (title.isEmpty || layout['isLive'] == true) return false;
  final duration = layout['duration'];
  final seconds = duration is int
      ? duration
      : int.tryParse(duration?.toString() ?? '');
  if (seconds == null || seconds < 30 || seconds > 3 * 60 * 60) return false;
  return true;
}

Future<void> updateSongLikeStatus(
  dynamic songId,
  bool add, {
  Map? songData,
}) async {
  try {
    final normalizedSongId = songId?.toString().trim() ?? '';
    if (normalizedSongId.isEmpty) return;

    final updateToken = ++_songLikeUpdateToken;
    _latestSongLikeUpdateTokens[normalizedSongId] = updateToken;
    // Prevent unbounded growth: evict oldest entries.
    if (_latestSongLikeUpdateTokens.length > _maxSongLikeTokenEntries) {
      final keysToRemove = _latestSongLikeUpdateTokens.keys
          .take(_latestSongLikeUpdateTokens.length - _maxSongLikeTokenEntries)
          .toList();
      for (final k in keysToRemove) {
        _latestSongLikeUpdateTokens.remove(k);
      }
    }

    final songToAdd = add
        ? await _resolveSongForLikedStatus(normalizedSongId, songData)
        : null;

    if (_latestSongLikeUpdateTokens[normalizedSongId] != updateToken) {
      return;
    }

    final updatedLikedSongs = _deduplicateLikedSongs(userLikedSongsList.value);

    if (add) {
      if (songToAdd != null &&
          !updatedLikedSongs.any(
            (song) => song['ytid']?.toString() == normalizedSongId,
          )) {
        updatedLikedSongs.insert(0, songToAdd);
      }
    } else {
      updatedLikedSongs.removeWhere(
        (song) => song['ytid']?.toString() == normalizedSongId,
      );
    }

    if (_likedSongIdsAreEqual(userLikedSongsList.value, updatedLikedSongs))
      return;

    userLikedSongsList.value = updatedLikedSongs;
    _syncLikedSongIdsSet();
    await addOrUpdateData<List>('user', 'likedSongs', userLikedSongsList.value);
    // Journal intent even offline/signed out, before attempting remote writes.
    await YouTubeMusicSyncService().recordFavorite(
      normalizedSongId,
      add,
      songToAdd,
    );
  } catch (e, stackTrace) {
    logger.log(
      'Error updating song like status',
      error: e,
      stackTrace: stackTrace,
    );
  }
}

Future<Map?> _resolveSongForLikedStatus(String songId, Map? songData) async {
  if (songData?['ytid']?.toString() == songId) {
    return Map<String, dynamic>.from(songData!);
  }

  final cachedSong = _findSongById(userLikedSongsList.value, songId);
  if (cachedSong != null) return Map<String, dynamic>.from(cachedSong);

  return getSongDetails(userLikedSongsList.value.length, songId);
}

Map? _findSongById(Iterable<dynamic> songs, String songId) {
  for (final song in songs) {
    if (song is Map && song['ytid']?.toString() == songId) return song;
  }

  return null;
}

List _deduplicateLikedSongs(Iterable<dynamic> likedSongs) {
  final seenSongIds = <String>{};
  final deduplicatedSongs = [];

  for (final song in likedSongs) {
    if (song is! Map) {
      deduplicatedSongs.add(song);
      continue;
    }

    final songId = song['ytid']?.toString();
    if (songId == null || songId.isEmpty) {
      deduplicatedSongs.add(song);
      continue;
    }

    if (seenSongIds.add(songId)) {
      deduplicatedSongs.add(song);
    }
  }

  return deduplicatedSongs;
}

bool _likedSongIdsAreEqual(List previous, List updated) {
  if (previous.length != updated.length) return false;

  for (var i = 0; i < previous.length; i++) {
    final previousSong = previous[i];
    final updatedSong = updated[i];
    if (previousSong is! Map || updatedSong is! Map) {
      if (previousSong != updatedSong) return false;
      continue;
    }

    if (previousSong['ytid']?.toString() != updatedSong['ytid']?.toString()) {
      return false;
    }
  }

  return true;
}

Future<void> renameSongInLikedSongs(
  dynamic songId,
  String newTitle,
  String newArtist,
) async {
  try {
    final songIndex = userLikedSongsList.value.indexWhere(
      (song) => song['ytid'] == songId,
    );

    if (songIndex != -1) {
      final updatedList = List.from(userLikedSongsList.value);
      updatedList[songIndex] = Map.from(updatedList[songIndex] as Map)
        ..['title'] = newTitle
        ..['artist'] = newArtist;
      userLikedSongsList.value = updatedList;

      unawaited(
        addOrUpdateData<List>('user', 'likedSongs', userLikedSongsList.value),
      );
    }
  } catch (e, stackTrace) {
    logger.log(
      'Error renaming song in liked songs',
      error: e,
      stackTrace: stackTrace,
    );
    rethrow;
  }
}

bool isSongAlreadyLiked(songIdToCheck) {
  final songId = songIdToCheck?.toString();
  if (songId == null || songId.isEmpty) return false;
  if (!identical(_likedSongIdsSnapshot, userLikedSongsList.value)) {
    _syncLikedSongIdsSet();
  }
  return _likedSongIdsSet.contains(songId);
}

bool isPlaylistAlreadyLiked(playlistIdToCheck) {
  final playlistId = playlistIdToCheck?.toString();
  if (playlistId == null || playlistId.isEmpty) return false;
  return userLikedPlaylists.value.any(
    (playlist) => playlist['ytid']?.toString() == playlistId,
  );
}

bool isSongAlreadyOffline(songIdToCheck) {
  final songId = songIdToCheck?.toString();
  if (songId == null || songId.isEmpty) return false;
  if (!identical(_offlineSongIdsSnapshot, userOfflineSongs.value)) {
    _syncOfflineSongIdsSet();
  }
  return _offlineSongIdsSet.contains(songId);
}

bool isPlaylistFullyOffline(List songs) {
  if (songs.isEmpty) return false;
  if (!identical(_offlineSongIdsSnapshot, userOfflineSongs.value)) {
    _syncOfflineSongIdsSet();
  }
  return songs.every(
    (s) => _offlineSongIdsSet.contains(s['ytid']?.toString() ?? ''),
  );
}

const minimumOfflineAudioBytes = 51201;

bool _isPlayableAudioFile(String? path) {
  if (path == null || path.isEmpty) return false;
  try {
    final file = File(path);
    // 50 KB minimum — 8 KB was too low and marked truncated files as valid.
    return file.existsSync() && file.lengthSync() >= minimumOfflineAudioBytes;
  } catch (e) {
    logger.log('_isPlayableAudioFile check failed', error: e);
    return false;
  }
}

Map<String, dynamic> getOfflineSongByYtid(
  String ytid, {
  bool verifyFiles = true,
}) {
  try {
    if (ytid.isEmpty) return <String, dynamic>{};

    final song = userOfflineSongs.value.firstWhere(
      (s) => s['ytid'] == ytid,
      orElse: () => <String, dynamic>{},
    );
    final result = Map<String, dynamic>.from(song);
    if (applicationDirPath.isEmpty) {
      return result;
    }
    // iOS moves the app container (its UUID changes) on every reinstall or
    // update, so any absolute path stored at download time goes stale and the
    // file "disappears". Downloads are named deterministically by ytid, so
    // always resolve against the CURRENT container instead of trusting the
    // stored path. This keeps offline playback working across app updates.
    // A Hive miss still counts as playable if the file is on disk.
    final currentAudioPath = FilePaths.getAudioPath(ytid);
    if (!verifyFiles) {
      if (result['audioPath'] != null) result['audioPath'] = currentAudioPath;
      if (result['artworkPath'] != null)
        result['artworkPath'] = FilePaths.getArtworkPath(ytid);
      return result;
    }
    if (_isPlayableAudioFile(currentAudioPath)) {
      result
        ..['audioPath'] = currentAudioPath
        ..['ytid'] = ytid;
    }
    final currentArtworkPath = FilePaths.getArtworkPath(ytid);
    if (File(currentArtworkPath).existsSync()) {
      result['artworkPath'] = currentArtworkPath;
    }
    return result;
  } catch (_) {
    return <String, dynamic>{};
  }
}

/// True when a fully downloaded copy exists on disk and is large enough
/// to be a real audio file (not a 0-byte failed download).
bool hasPlayableOfflineFile(String? ytid) {
  if (ytid == null || ytid.isEmpty) return false;
  final hivePath = getOfflineSongByYtid(ytid)['audioPath']?.toString();
  if (_isPlayableAudioFile(hivePath)) return true;
  if (applicationDirPath.isEmpty) return false;
  return _isPlayableAudioFile(FilePaths.getAudioPath(ytid));
}

Future<List<String>> getSearchSuggestions(String query) async {
  // Custom implementation:

  // const baseUrl = 'https://suggestqueries.google.com/complete/search';
  // final parameters = {
  //   'client': 'firefox',
  //   'ds': 'yt',
  //   'q': query,
  // };

  // final uri = Uri.parse(baseUrl).replace(queryParameters: parameters);

  // try {
  //   final response = await http.get(
  //     uri,
  //     headers: {
  //       'User-Agent':
  //           'Mozilla/5.0 (Windows NT 10.0; rv:96.0) Gecko/20100101 Firefox/96.0',
  //     },
  //   );

  //   if (response.statusCode == 200) {
  //     final suggestions = jsonDecode(response.body)[1] as List<dynamic>;
  //     final suggestionStrings = suggestions.cast<String>().toList();
  //     return suggestionStrings;
  //   }
  // } catch (e, stackTrace) {
  //   logger.log('Error in getSearchSuggestions:$e\n$stackTrace');
  // }

  // Built-in implementation:

  final suggestions = await ytClient.search.getQuerySuggestions(query);

  return suggestions;
}

/// Fetches a list of similar / radio songs based on track ID or title & artist.
/// Fully guards against invalid YouTube IDs (e.g. JioSaavn tokens) and uses
/// search resolution and radio fallback gracefully.
Future<List<Map<String, dynamic>>> getSimilarSongs(
  String songYtId, {
  String? title,
  String? artist,
  int limit = 4,
}) async {
  try {
    String? validYtId;
    if (isValidYoutubeVideoId(songYtId)) {
      validYtId = songYtId;
    } else if (title != null && title.isNotEmpty) {
      final query = (artist != null && artist.isNotEmpty)
          ? '$title $artist'
          : title;
      try {
        final results = await fetchSongsList(query);
        for (final r in results) {
          final id = r['ytid']?.toString();
          if (id != null && isValidYoutubeVideoId(id)) {
            validYtId = id;
            break;
          }
        }
      } catch (e) {
        logger.log('Error resolving YouTube ID for similar song search: $e');
      }
    }

    if (validYtId != null) {
      final radioTracks = await YouTubeMusicSyncService().fetchRadioTracks(
        validYtId,
        limit: limit,
      );
      if (radioTracks.isNotEmpty) {
        return radioTracks.map((t) {
          final m = Map<String, dynamic>.from(t);
          m['source'] = 'youtube-recommended';
          return m;
        }).toList();
      }

      try {
        final song = await ytClient.videos.get(validYtId);
        final relatedSongs = await ytClient.videos.getRelatedVideos(song) ?? [];
        if (relatedSongs.isNotEmpty) {
          return relatedSongs.take(limit).map((v) {
            final layout = returnSongLayout(0, v);
            layout['source'] = 'youtube-recommended';
            return layout;
          }).toList();
        }
      } catch (e) {
        logger.log('Error getting related videos for $validYtId: $e');
      }
    }

    final fallbackQuery = (artist != null && artist.isNotEmpty)
        ? artist
        : title;
    if (fallbackQuery != null && fallbackQuery.isNotEmpty) {
      try {
        final searchRes = await fetchSongsList(fallbackQuery);
        final candidates = <Map<String, dynamic>>[];
        for (final candidate in searchRes) {
          final candidateId = candidate['ytid']?.toString();
          if (candidateId != null && candidateId != songYtId) {
            final res = Map<String, dynamic>.from(candidate);
            res['source'] = 'youtube-recommended';
            candidates.add(res);
            if (candidates.length >= limit) break;
          }
        }
        if (candidates.isNotEmpty) return candidates;
      } catch (_) {}
    }
  } catch (e, stackTrace) {
    logger.log(
      'Error while fetching next similar songs:',
      error: e,
      stackTrace: stackTrace,
    );
  }
  return [];
}

Future<Map?> getSimilarSong(
  String songYtId, {
  String? title,
  String? artist,
}) async {
  final list = await getSimilarSongs(
    songYtId,
    title: title,
    artist: artist,
    limit: 1,
  );
  return list.firstOrNull;
}

/// In-memory cache of the audio stream picked for a song at the current
/// quality setting. The Hive cache only keeps the URL, so without this every
/// caller that needs the stream itself (bitrate, codec) would fetch the
/// manifest again right after playback already resolved it.
final Map<
  String,
  ({AudioOnlyStreamInfo stream, YoutubeApiClient? client, DateTime resolvedAt})
>
_selectedAudioStreams = {};

const _maxSelectedAudioStreams = 50;

String _selectedAudioStreamKey(String songId) =>
    '${songId}_${audioQualitySetting.value}_youtube';

/// Returns the stream resolved earlier for a song, unless it is old enough
/// that its URL may have expired.
({AudioOnlyStreamInfo stream, YoutubeApiClient? client})?
_getSelectedAudioStream(String songId) {
  final key = _selectedAudioStreamKey(songId);
  final entry = _selectedAudioStreams[key];
  if (entry == null) return null;

  if (DateTime.now().difference(entry.resolvedAt) > _cacheValidationDuration) {
    _selectedAudioStreams.remove(key);
    return null;
  }

  if (isHeAacStream(entry.stream)) {
    _selectedAudioStreams.remove(key);
    return null;
  }

  return (stream: entry.stream, client: entry.client);
}

void _cacheSelectedAudioStream(
  String songId,
  AudioOnlyStreamInfo stream,
  YoutubeApiClient? client,
) {
  if (_selectedAudioStreams.length >= _maxSelectedAudioStreams) {
    _selectedAudioStreams.remove(_selectedAudioStreams.keys.first);
  }

  _selectedAudioStreams[_selectedAudioStreamKey(songId)] = (
    stream: stream,
    client: client,
    resolvedAt: DateTime.now(),
  );
}

/// Drops cached stream URLs for every song (e.g. after changing InnerTube client).
Future<void> invalidateAllSongStreamCaches() async {
  _selectedAudioStreams.clear();
  if (!Hive.isBoxOpen('cache')) return;
  final box = Hive.box('cache');
  for (final key in box.keys) {
    if (key is String && key.startsWith('song_')) {
      await deleteData('cache', key);
    }
  }
}

/// Drops both cached forms of a song's stream, so the next request resolves
/// it again. Used when a cached URL turns out to be dead.
Future<void> invalidateSongStreamCache(String songId) async {
  _selectedAudioStreams.remove(_selectedAudioStreamKey(songId));
  for (final source in ['youtube', 'jiosaavn']) {
    final key = _songStreamCacheKey(songId, source);
    await deleteData('cache', key);
    await deleteData('cache', _songStreamCacheMetaKey(songId, source));
  }
  if (jiosaavnAvailable || Hive.isBoxOpen('saavn_match_cache')) {
    await SourceResolver().deleteCachedMatch(songId);
  }
  // Remove the pre-source cache key written by older builds. It is unsafe to
  // reuse because it does not say which service produced the URL.
  await deleteData('cache', 'song_${songId}_${audioQualitySetting.value}_url');
}

/// Fetches the best available audio stream for a song.
Future<AudioOnlyStreamInfo?> fetchBestAudioStream(
  String? songId, {
  String? quality,
}) async {
  try {
    if (songId == null || songId.isEmpty) {
      logger.log('fetchBestAudioStream: songId is null or empty');
      return null;
    }

    final cachedSelection = quality == null
        ? _getSelectedAudioStream(songId)
        : null;
    if (cachedSelection != null &&
        isPlayableYoutubeStreamUrl(cachedSelection.stream.url)) {
      return cachedSelection.stream;
    }
    if (cachedSelection != null) {
      _selectedAudioStreams.remove(_selectedAudioStreamKey(songId));
    }

    final resolvedManifest = await _fetchStreamManifest(songId);
    final audioStream = resolvedManifest?.manifest.audioOnly;
    if (audioStream == null || audioStream.isEmpty) {
      logger.log('fetchBestAudioStream: no audio streams for $songId');
      return null;
    }

    final playable = audioStream
        .where(
          (stream) =>
              isPlayableYoutubeStreamUrl(stream.url) &&
              isAudioOnlyMimeStream(stream),
        )
        .toList();
    if (playable.isEmpty) {
      logger.log(
        'fetchBestAudioStream: no playable audio/* URLs for $songId '
        '(rejected video/muxed mime types)',
      );
      return null;
    }

    final selectedStream = selectAudioOnlyStreamForQuality(
      playable.sortByBitrate(),
      requestedKbps: int.tryParse(quality ?? ''),
    );
    if (!isPlayableYoutubeStreamUrl(selectedStream.url)) {
      logger.log(
        'fetchBestAudioStream: selected stream URL invalid for $songId',
      );
      return null;
    }
    logger.log(
      'Selected YT stream itag=${selectedStream.tag} '
      'codec=${selectedStream.audioCodec} '
      'bitrate=${selectedStream.bitrate.kiloBitsPerSecond.round()}kbps'
      '${isHeAacStream(selectedStream) ? ' (HE-AAC — will clip duration)' : ''}',
    );
    _cacheSelectedAudioStream(songId, selectedStream, resolvedManifest!.client);
    return selectedStream;
  } on TimeoutException catch (_) {
    logger.log('fetchBestAudioStream request timed out for $songId');
    return null;
  } catch (e, stackTrace) {
    logger.log(
      'Error while fetching best audio stream',
      error: e,
      stackTrace: stackTrace,
    );
    return null;
  }
}

/// Fire-and-forget Saavn match while YouTube is already playing.
/// Never await this on the between-track gap — iOS will suspend on silence.
Future<void> _cacheSaavnMatchInBackground(Map song) async {
  final songId = song['ytid']?.toString() ?? '';
  if (songId.isEmpty || !jiosaavnAvailable) return;
  try {
    final existing = await SourceResolver().getCachedMatch(songId);
    if (existing != null) return;
    final match = await SourceResolver()
        .resolveAudioSource(song)
        .timeout(const Duration(seconds: 12), onTimeout: () => null);
    if (match != null && match['url'] != null) {
      final url = match['url'] as String;
      if (url.isNotEmpty) {
        await _cacheResolvedStream(songId, 'jiosaavn', url, {
          'bitrate': match['bitrate'],
          'format': match['format'],
          'image': match['image'],
        });
        logger.log('Background-cached JioSaavn match for $songId');
      }
    }
  } catch (e) {
    logger.log('Background Saavn cache failed for $songId: $e');
  }
}

final _streamResolutions = StreamResolutionPool();

/// A tap reuses an in-flight warmup rather than starting a second manifest call.
Future<String?> fetchSongStreamUrl(
  Map song,
  bool isLive, {
  bool Function()? abandon,
}) => _streamResolutions.resolve(
  (
    song['ytid']?.toString(),
    song['forceSource']?.toString(),
    preferredStreamSourceForSong(song),
    song['catalogOrigin']?.toString() ?? song['source']?.toString(),
    preferredSource.value,
    jiosaavnQuality.value,
    jiosaavnAvailable,
    isLive,
  ),
  song,
  (copy) => _fetchSongStreamUrl(copy, isLive),
  abandon: abandon,
);

Future<String?> _fetchSongStreamUrl(Map song, bool isLive) async {
  final songId = song['ytid']?.toString() ?? '';
  try {
    if (song['catalogOrigin'] == 'local' || song['source'] == 'local') {
      return null;
    }
    if (songId.isEmpty) {
      logger.log('fetchSongStreamUrl: songId is empty');
      return null;
    }
    if (isLive) {
      final streamInfo = await ytClient.videos.streamsClient
          .getHttpLiveStreamUrl(VideoId(songId));
      return streamInfo;
    }

    const cacheDuration = songCacheDuration;
    final forceSource = song['forceSource']?.toString();
    final resolveYoutube = songShouldResolveYoutube(song);
    final pref = preferredSource.value;
    final forceJiosaavn =
        jiosaavnAvailable &&
        (forceSource == 'jiosaavn' || forceSource == 'saavn');
    // Saavn search ONLY when the user pinned JioSaavn. `auto` must never wait
    // on a title/artist lookup between tracks — iOS suspends on silence gaps.
    final allowSaavnSearch =
        jiosaavnAvailable &&
        !resolveYoutube &&
        (forceJiosaavn || pref == 'jiosaavn' || pref == 'saavn');
    final preference = resolveYoutube
        ? 'youtube'
        : (allowSaavnSearch ? 'jiosaavn' : 'youtube');

    logger.log(
      'Resolution start for songId=$songId',
      data: {
        'title': song['title'],
        'force': forceSource ?? '-',
        'target': preference,
        'saavnSearch': allowSaavnSearch,
        'catalogOrigin': song['catalogOrigin']?.toString() ?? '-',
        'offlineMode': offlineMode.value,
      },
    );

    // Instant cache hits only (no network). For auto, accept either provider's
    // already-resolved URL so a prior Saavn match can play without searching.
    final cacheOrder = preference == 'jiosaavn'
        ? <String>['jiosaavn', 'youtube']
        : <String>['youtube', 'jiosaavn'];
    for (final cachePreference in cacheOrder) {
      // Skip Saavn cache when user pinned YouTube.
      if (cachePreference == 'jiosaavn' &&
          (!jiosaavnAvailable ||
              forceSource == 'youtube' ||
              pref == 'youtube')) {
        continue;
      }
      // Skip YouTube cache when user forced Saavn.
      if (cachePreference == 'youtube' && forceJiosaavn) {
        continue;
      }
      final sourceKey = _songStreamCacheKey(songId, cachePreference);
      final cacheBox = await Hive.openBox('cache');
      final metadata = cacheBox.get(
        _songStreamCacheMetaKey(songId, cachePreference),
      );
      final cachedUrl = await _getCachedSongUrl(
        sourceKey,
        cacheDuration,
        userAgent: metadata is Map ? metadata['userAgent']?.toString() : null,
      );
      if (cachedUrl == null) continue;

      final cachedUri = Uri.tryParse(cachedUrl);
      if (cachePreference == 'youtube' &&
          cachedUri != null &&
          isYoutubeStreamUrlExpired(cachedUri)) {
        logger.log(
          'Cached YouTube URL expired for $songId',
          data: {'expire': cachedUri.queryParameters['expire'] ?? '-'},
        );
        await invalidateSongStreamCache(songId);
        continue;
      }
      if (metadata is Map && metadata['source'] == cachePreference) {
        final isBadHeAac =
            cachePreference == 'youtube' && _isCachedHeAacYoutube(metadata);
        final isWrongSaavnQuality =
            cachePreference == 'jiosaavn' &&
            '${metadata['bitrate']}' != jiosaavnQuality.value;
        if (!isBadHeAac && !isWrongSaavnQuality) {
          song['resolvedSource'] = cachePreference;
          song['resolvedBitrate'] = metadata['bitrate'];
          song['resolvedFormat'] = metadata['format'];
          song['resolvedUserAgent'] = metadata['userAgent'];
          if (metadata['image'] != null) {
            song['highResImage'] = metadata['image'];
            song['image'] = metadata['image'];
          }
          if (cachePreference == 'youtube') {
            final cachedDuration = metadata['durationSeconds'];
            if (cachedDuration is int && cachedDuration > 0) {
              song['duration'] = cachedDuration;
            } else if (cachedUri != null) {
              final urlDur = youtubeStreamDurationSeconds(cachedUri);
              if (urlDur != null) {
                song['duration'] = urlDur;
              } else {
                unawaited(ensureYoutubeCatalogDuration(song));
              }
            } else {
              unawaited(ensureYoutubeCatalogDuration(song));
            }
          }
          logger.log(
            'Using cached $cachePreference URL for $songId',
            data: {
              'host': cachedUri?.host ?? '-',
              'dur': song['duration']?.toString() ?? '-',
              'expire': cachedUri?.queryParameters['expire'] ?? '-',
            },
          );
          return cachedUrl;
        }
      }
      await invalidateSongStreamCache(songId);
    }

    final isSaavnTrack =
        song['source'] == 'saavn' ||
        song['source'] == 'jiosaavn' ||
        song['catalogOrigin'] == 'saavn' ||
        song['catalogOrigin'] == 'jiosaavn' ||
        (song['encrypted_media_url'] != null &&
            song['encrypted_media_url'].toString().isNotEmpty);

    // Blocking Saavn search — only when the user selected JioSaavn or track is from Saavn catalog.
    // Keep the timeout well under a second for auto-searches so a miss does not create a
    // lock-screen silence gap that lets iOS suspend the audio session.
    if ((allowSaavnSearch || (isSaavnTrack && pref != 'youtube')) &&
        forceSource != 'youtube' &&
        jiosaavnAvailable) {
      try {
        final saavnSource = await SourceResolver()
            .resolveAudioSource(song)
            .timeout(
              // Bound source lookup; warmed URLs avoid this work between tracks.
              Duration(milliseconds: isSaavnTrack ? 4000 : 8000),
              onTimeout: () {
                logger.log(
                  'JioSaavn search timed out for $songId — '
                  'not blocking playback gap',
                );
                return null;
              },
            );
        if (saavnSource != null && saavnSource['url'] != null) {
          final url = saavnSource['url'] as String;
          if (url.isNotEmpty) {
            song['resolvedSource'] = 'jiosaavn';
            song['resolvedBitrate'] = saavnSource['bitrate'];
            song['resolvedFormat'] = saavnSource['format'];
            if (saavnSource['image'] != null) {
              song['highResImage'] = saavnSource['image'];
              song['image'] = saavnSource['image'];
            }
            await _cacheResolvedStream(songId, 'jiosaavn', url, {
              'bitrate': saavnSource['bitrate'],
              'format': saavnSource['format'],
              'image': saavnSource['image'],
            });
            logger.log(
              'Resolved JioSaavn stream: host=${Uri.tryParse(url)?.host}',
            );
            return url;
          }
        }
        if (forceJiosaavn) {
          logger.log('JioSaavn forced but no match for $songId');
          return null;
        }
        logger.log(
          'JioSaavn match not found for $songId, falling back to YouTube',
        );
      } catch (e) {
        if (forceJiosaavn) {
          logger.log('JioSaavn forced resolution failed for $songId: $e');
          return null;
        }
        logger.log('JioSaavn resolution error: $e, falling back to YouTube');
      }
    }

    if (forceJiosaavn) {
      logger.log('JioSaavn forced but unavailable for $songId');
      return null;
    }

    // YouTube Music resolution — coverage path for auto / youtube / Saavn miss.
    var resolvedYtSongId = song['resolvedYoutubeId']?.toString() ?? songId;
    if (isSaavnTrack && !isValidYoutubeVideoId(resolvedYtSongId)) {
      try {
        final query = '${song['title']} ${song['artist']}'.trim();
        final searchRes = await ytMusicClient.music.searchSongs(query);
        for (final candidate in searchRes) {
          final track = returnSongLayout(0, candidate);
          if (TrackMatcher.isExactMatch(
            titleA: song['title']?.toString() ?? '',
            artistA: song['artist']?.toString() ?? '',
            durationA: song['duration'],
            titleB: track['title']?.toString() ?? '',
            artistB: track['artist']?.toString() ?? '',
            durationB: track['duration'],
          )) {
            resolvedYtSongId = candidate.id.toString();
            song['resolvedYoutubeId'] = resolvedYtSongId;
            break;
          }
        }
      } catch (e) {
        logger.log('Fallback YouTube search for Saavn track failed: $e');
      }
    }
    final selectedStream = await fetchBestAudioStream(resolvedYtSongId);
    if (selectedStream == null) {
      setYoutubeStreamError(_youtubeStreamFailureMessage());
      logger.log('fetchSongStreamUrl: no YouTube audio streams for $songId');
      return null;
    }

    final url = selectedStream.url.toString();
    if (!isPlayableYoutubeStreamUrl(selectedStream.url)) {
      setYoutubeStreamError(_youtubeStreamFailureMessage());
      logger.log('fetchSongStreamUrl: invalid stream URL for $songId');
      return null;
    }
    final selectedClient = _getSelectedAudioStream(resolvedYtSongId)?.client;
    final userAgent = selectedClient == null
        ? null
        : _youtubeClientUserAgent(selectedClient);

    song['resolvedSource'] = 'youtube';
    song['resolvedBitrate'] = selectedStream.bitrate.kiloBitsPerSecond.round();
    song['resolvedFormat'] = selectedStream.audioCodec;
    song['resolvedItag'] = selectedStream.tag;
    song['resolvedUserAgent'] = userAgent;

    // Set before the source is built so the media item and the near-end check
    // never see the player's (sometimes doubled) reported duration.
    final streamDuration = youtubeStreamDurationSeconds(selectedStream.url);
    if (streamDuration != null) {
      song['duration'] = streamDuration;
    }

    await _cacheResolvedStream(songId, 'youtube', url, {
      'bitrate': song['resolvedBitrate'],
      'format': song['resolvedFormat'],
      'itag': selectedStream.tag,
      'userAgent': userAgent,
      'durationSeconds': streamDuration,
    });
    if (streamDuration == null) {
      unawaited(ensureYoutubeCatalogDuration(song));
    }
    // Opportunistic Saavn match AFTER YouTube is ready — never on the gap.
    // Caches a better source for next time when idle/playing.
    if (!allowSaavnSearch &&
        jiosaavnAvailable &&
        preferredSource.value == 'auto') {
      unawaited(_cacheSaavnMatchInBackground(song));
    }
    logger.log('Resolved YouTube stream: host=${Uri.tryParse(url)?.host}');
    return url;
  } on TimeoutException catch (_) {
    setYoutubeStreamError(_youtubeStreamFailureMessage());
    logger.log('fetchSongStreamUrl timed out for $songId');
    return null;
  } catch (e, stackTrace) {
    logger.log(
      'Error in fetchSongStreamUrl for $songId:',
      error: e,
      stackTrace: stackTrace,
    );
    return null;
  }
}

Future<Map<String, dynamic>> getSongDetails(
  int songIndex,
  String songId,
) async {
  try {
    final song = await ytClient.videos.get(songId);
    return returnSongLayout(songIndex, song);
  } catch (e, stackTrace) {
    logger.log(
      'Error while getting song details',
      error: e,
      stackTrace: stackTrace,
    );
    rethrow;
  }
}

final _lyricRequests = LyricsRequestCache(LyricsManager().fetchLyrics);
int _lyricRequestGeneration = 0;
Future<String?> getSongLyrics(String? artist, String title) async {
  if (artist == null) return null;
  final key = '$artist - $title';
  if (lastFetchedLyrics == key) return lyrics.value;
  final generation = ++_lyricRequestGeneration;
  lyrics.value = null;
  var result = await _lyricRequests.fetch(artist, title);
  result = result?.replaceAll(RegExp(r'\n{2,}'), '\n');
  if (generation == _lyricRequestGeneration) {
    lyrics.value = result;
    lastFetchedLyrics = result == null ? null : key;
  }
  return result;
}

final _offlineRegistry = OfflineSongRegistry(
  read: () => userOfflineSongs.value,
  persist: (songs) =>
      addOrUpdateData<List>('userNoBackup', 'offlineSongs', songs),
  publish: (songs) {
    userOfflineSongs.value = songs;
    _syncOfflineSongIdsSet();
  },
);

final Map<String, AsyncOperationQueue> _downloadLocks = {};
final Map<String, int> _downloadUsers = {};

Future<bool> makeSongOffline(
  dynamic song, {
  String? source,
  String? quality,
  DownloadCancellation? cancellation,
}) async {
  final id = song is Map ? song['ytid']?.toString() : null;
  if (id == null || id.isEmpty) return false;
  if (song is Map &&
      (song['catalogOrigin'] == 'local' || song['source'] == 'local')) {
    return false;
  }
  final token = cancellation ?? DownloadCancellation();
  final selectedSource = source ?? downloadSource.value;
  final selectedQuality = quality ?? downloadQuality.value;
  final job = downloadActivity.begin(
    song as Map,
    token,
    source: selectedSource,
    quality: selectedQuality,
    canCancel: cancellation == null,
  );
  var success = false;
  try {
    success = await _runOfflineAssetOperation(id, () async {
      if (token.isCancelled) return false;
      downloadActivity.start(job);
      return downloadWithSourceFallback(
        preferred: selectedSource,
        saavnEnabled: jiosaavnAvailable,
        isCancelled: () => token.isCancelled,
        onFallback: (provider) {
          downloadActivity.retrying(
            job,
            provider == 'saavn' ? 'jiosaavn' : provider,
          );
          showAppToast(
            'Trying ${provider == 'saavn' ? 'JioSaavn' : 'YouTube Music'} for this download',
          );
        },
        attempt: (provider) => _makeSongOffline(
          song,
          source: provider,
          quality: selectedQuality,
          cancellation: token,
          onProgress: (received, total) =>
              downloadActivity.progress(job, received, total),
          onResolved: (source, bitrate) =>
              downloadActivity.resolved(job, source, bitrate),
        ),
      );
    });
    return success;
  } finally {
    downloadActivity.finish(job, success);
  }
}

Future<bool> _runOfflineAssetOperation(
  String id,
  Future<bool> Function() operation,
) async {
  final lock = _downloadLocks.putIfAbsent(id, AsyncOperationQueue.new);
  _downloadUsers[id] = (_downloadUsers[id] ?? 0) + 1;
  try {
    return await lock.run(operation);
  } finally {
    final remaining = (_downloadUsers[id] ?? 1) - 1;
    if (remaining == 0) {
      _downloadUsers.remove(id);
      _downloadLocks.remove(id);
    } else {
      _downloadUsers[id] = remaining;
    }
  }
}

Future<bool> _makeSongOffline(
  dynamic song, {
  String? source,
  String? quality,
  required DownloadCancellation cancellation,
  void Function(int received, int? total)? onProgress,
  void Function(String source, int? bitrate)? onResolved,
}) async {
  try {
    final normalizedSource = source == 'jiosaavn'
        ? 'saavn'
        : (source == 'best' || source == 'auto')
        ? null
        : source;
    final String? ytid = song['ytid'];

    if (ytid == null || ytid.isEmpty) {
      logger.log('makeSongOffline: song["ytid"] is null or empty');
      return false;
    }

    final isSaavnTrack =
        normalizedSource == 'saavn' ||
        song['source'] == 'saavn' ||
        song['source'] == 'jiosaavn' ||
        song['catalogOrigin'] == 'saavn' ||
        song['catalogOrigin'] == 'jiosaavn' ||
        song['resolvedSource'] == 'saavn' ||
        song['resolvedSource'] == 'jiosaavn' ||
        song['downloadSource'] == 'saavn' ||
        song['downloadSource'] == 'jiosaavn' ||
        song['saavnId'] != null ||
        (song['encrypted_media_url'] != null &&
            song['encrypted_media_url'].toString().isNotEmpty) ||
        !isValidYoutubeVideoId(ytid);

    if (!isValidYoutubeVideoId(ytid) && !isSaavnTrack) {
      logger.log('makeSongOffline: invalid ytid "$ytid"');
      return false;
    }

    if (isSongAlreadyOffline(ytid)) {
      // Tiny/truncated files must not short-circuit a real download.
      if (hasPlayableOfflineFile(ytid)) {
        final existing = getOfflineSongByYtid(ytid);
        final actual = existing['downloadSource'];
        final requested = normalizedSource == 'saavn'
            ? 'jiosaavn'
            : normalizedSource;
        final kbps = int.tryParse(quality ?? '0') ?? 0;
        if ((requested == null || requested == 'auto' || actual == requested) &&
            (kbps == 0 ||
                existing['requestedDownloadQuality'] == quality ||
                (existing['audioBitrateKbps'] as num? ?? 0) >= kbps)) {
          return true;
        }
      }
      logger.log(
        'makeSongOffline: offline Hive entry for $ytid lacks playable file — re-downloading',
      );
    }

    final offlineSong = Map<String, dynamic>.from(song as Map)
      ..remove('forceSource')
      ..remove('resolvedSource')
      ..remove('resolvedBitrate')
      ..remove('resolvedFormat')
      ..remove('resolvedUserAgent');
    var downloadedSource = normalizedSource == 'saavn'
        ? 'jiosaavn'
        : normalizedSource == 'youtube'
        ? 'youtube'
        : null;

    final audioPath = FilePaths.getAudioPath(ytid);
    final audioFile = File(audioPath);
    final artworkPath = FilePaths.getArtworkPath(ytid);

    await audioFile.parent.create(recursive: true);

    int? audioBitrateKbps;
    String? audioCodec;
    cancellation.check();
    try {
      Map<String, dynamic>? saavnSource;
      var mappedQuality = quality;
      // Saavn only supports 96/160/320, map 128 -> 96
      if (mappedQuality == '128') mappedQuality = '96';
      if (normalizedSource != 'youtube' && jiosaavnAvailable) {
        try {
          saavnSource = await SourceResolver()
              .resolveAudioSource(offlineSong, quality: mappedQuality)
              .timeout(const Duration(seconds: 8), onTimeout: () => null);
        } catch (e) {
          logger.log('Saavn resolve for offline failed: $e');
        }
      }

      if (saavnSource != null && saavnSource['url'] != null) {
        downloadedSource = 'jiosaavn';
        audioBitrateKbps = saavnSource['bitrate'] as int?;
        audioCodec = saavnSource['format'] as String?;
        onResolved?.call('jiosaavn', audioBitrateKbps);
        final url = saavnSource['url'] as String;

        final req = http.Request('GET', Uri.parse(url));
        req.headers['User-Agent'] =
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15';
        final client = http.Client();
        try {
          final response = await cancellation.race(
            client.send(req).timeout(const Duration(seconds: 20)),
          );
          if (response.statusCode < 200 || response.statusCode >= 300) {
            logger.log('Saavn download HTTP ${response.statusCode} for $ytid');
            throw HttpException('Saavn HTTP ${response.statusCode}');
          }
          await writeDownloadAtomically(
            destination: audioFile,
            minimumBytes: minimumOfflineAudioBytes,
            bytes: response.stream,
            cancellation: cancellation,
            expectedBytes: response.contentLength,
            onProgress: onProgress,
          );
        } finally {
          client.close();
        }
      } else {
        // An explicit source choice must not silently download another provider.
        if (normalizedSource == 'saavn') {
          logger.log('Selected JioSaavn download is unavailable for $ytid');
          return false;
        }
        cancellation.check();
        var youtubeId = offlineSong['resolvedYoutubeId']?.toString() ?? ytid;
        if (!isValidYoutubeVideoId(youtubeId)) {
          offlineSong['forceSource'] = 'youtube';
          await cancellation.race(fetchSongStreamUrl(offlineSong, false));
          youtubeId = offlineSong['resolvedYoutubeId']?.toString() ?? '';
          offlineSong.remove('forceSource');
          if (!isValidYoutubeVideoId(youtubeId)) {
            final query = '${offlineSong['title']} ${offlineSong['artist']}'
                .trim();
            if (query.isNotEmpty) {
              try {
                final searchRes = await cancellation.race(
                  fetchSongsList(query),
                );
                for (final cand in searchRes) {
                  final candId = cand['ytid']?.toString();
                  if (candId != null &&
                      isValidYoutubeVideoId(candId) &&
                      TrackMatcher.isExactMatch(
                        titleA: offlineSong['title']?.toString() ?? '',
                        artistA: offlineSong['artist']?.toString() ?? '',
                        durationA: offlineSong['duration'],
                        titleB: cand['title']?.toString() ?? '',
                        artistB: cand['artist']?.toString() ?? '',
                        durationB: cand['duration'],
                      )) {
                    youtubeId = candId;
                    offlineSong['resolvedYoutubeId'] = candId;
                    break;
                  }
                }
              } catch (_) {}
            }
          }
          if (!isValidYoutubeVideoId(youtubeId)) return false;
        }
        final audioManifest = await cancellation.race(
          fetchBestAudioStream(youtubeId, quality: quality),
        );
        if (audioManifest == null) {
          setYoutubeStreamError(_youtubeStreamFailureMessage());
          logger.log('makeSongOffline: audioManifest is null for $ytid');
          return false;
        }
        downloadedSource = 'youtube';
        audioBitrateKbps = audioManifest.bitrate.kiloBitsPerSecond.round();
        audioCodec = audioManifest.audioCodec;
        if (audioCodec.toLowerCase().startsWith('video/')) return false;
        onResolved?.call('youtube', audioBitrateKbps);

        final streamDuration = youtubeStreamDurationSeconds(audioManifest.url);
        if (streamDuration != null) {
          offlineSong['duration'] = streamDuration;
        }

        final selectedClient = _getSelectedAudioStream(youtubeId)?.client;
        final stream = ytClient.videos.streamsClient.get(
          audioManifest,
          ytClient: selectedClient,
        );
        await writeDownloadAtomically(
          destination: audioFile,
          minimumBytes: minimumOfflineAudioBytes,
          bytes: stream,
          cancellation: cancellation,
          expectedBytes: audioManifest.size.totalBytes,
          onProgress: onProgress,
        );
      }
    } catch (e, stackTrace) {
      logger.log(
        'Error downloading audio file',
        error: e,
        stackTrace: stackTrace,
      );
      return false;
    }

    // Do not mark offline in Hive unless the file is a real audio payload.
    if (!_isPlayableAudioFile(audioFile.path)) {
      logger.log(
        'makeSongOffline: downloaded file too small or missing for $ytid',
      );
      if (await audioFile.exists()) {
        await audioFile.delete();
      }
      return false;
    }
    if (downloadedSource == 'youtube' &&
        audioCodec != null &&
        audioCodec.toLowerCase().startsWith('video/')) {
      logger.log(
        'makeSongOffline: rejecting video mime download for $ytid ($audioCodec)',
      );
      if (await audioFile.exists()) {
        await audioFile.delete();
      }
      return false;
    }

    final artworkUrl =
        offlineSong['catalogImage']?.toString() ??
        offlineSong['highResImage']?.toString() ??
        offlineSong['image']?.toString();
    if (artworkUrl != null && artworkUrl.isNotEmpty) {
      final artwork = await _downloadAndSaveArtworkFile(
        artworkUrl,
        artworkPath,
      );
      if (artwork != null) offlineSong['artworkPath'] = artwork.path;
    }

    offlineSong['audioPath'] = audioFile.path;
    offlineSong['audioBitrateKbps'] = audioBitrateKbps;
    offlineSong['audioCodec'] = audioCodec;
    offlineSong['downloadSource'] = downloadedSource;
    offlineSong['requestedDownloadQuality'] = quality;
    offlineSong['dateAdded'] = DateTime.now().millisecondsSinceEpoch;

    try {
      await _offlineRegistry.upsert(offlineSong);
    } catch (e, st) {
      logger.log(
        'Error updating global offline songs list',
        error: e,
        stackTrace: st,
      );
      return false;
    }

    return true;
  } catch (e, stackTrace) {
    logger.log('Error making song offline', error: e, stackTrace: stackTrace);
    return false;
  }
}

Future<bool> removeSongFromOffline(dynamic songId) {
  final id = songId?.toString();
  if (id == null || id.isEmpty) return Future.value(false);
  return _runOfflineAssetOperation(id, () => _removeSongFromOffline(id));
}

Future<bool> _removeSongFromOffline(String songId) async {
  try {
    final audioPath = FilePaths.getAudioPath(songId);
    final audioFile = File(audioPath);
    final artworkPath = FilePaths.getArtworkPath(songId);
    final artworkFile = File(artworkPath);

    try {
      if (await audioFile.exists()) await audioFile.delete(recursive: true);
    } catch (e, stackTrace) {
      logger.log('Error deleting audio file', error: e, stackTrace: stackTrace);
    }

    try {
      if (await artworkFile.exists()) await artworkFile.delete(recursive: true);
    } catch (e, stackTrace) {
      logger.log(
        'Error deleting artwork file',
        error: e,
        stackTrace: stackTrace,
      );
    }

    try {
      await _offlineRegistry.remove(songId);
    } catch (e, st) {
      logger.log(
        'Error updating offline songs registry after removal',
        error: e,
        stackTrace: st,
      );
      return false;
    }

    return true;
  } catch (e, stackTrace) {
    logger.log(
      'Error removing song from offline storage',
      error: e,
      stackTrace: stackTrace,
    );
    return false;
  }
}

Future<File?> _downloadAndSaveArtworkFile(String url, String filePath) async {
  try {
    final artworkUri = Uri.parse(upgradeArtworkUrl(url, targetSize: 600));
    final response = await http
        .get(artworkUri)
        .timeout(const Duration(seconds: 4));

    if (response.statusCode == 200) {
      final square = await PlayerArtworkCache.squareCover(
        response.bodyBytes,
        videoThumbnail:
            artworkUri.host.endsWith('ytimg.com') &&
            (artworkUri.path.contains('/vi/') ||
                artworkUri.path.contains('/vi_webp/')),
      );
      if (square == null) return null;
      final file = File(filePath);
      await file.parent.create(recursive: true);
      await file.writeAsBytes(square);

      // Validate that the file was actually written
      if (await file.exists() && await file.length() > 0) {
        return file;
      } else {
        logger.log('Artwork file was not written properly: $filePath');
        return null;
      }
    } else {
      logger.log(
        'Failed to download file. Status code: ${response.statusCode}',
      );
    }
  } catch (e, stackTrace) {
    logger.log(
      'Error downloading and saving file',
      error: e,
      stackTrace: stackTrace,
    );
  }

  return null;
}

const recentlyPlayedSongsLimit = 100;

/// Updates the recently played list and listening count for [songId].
///
/// When [songFallback] is provided, its metadata is used to seed the history
/// entry if the song has never been played before. This avoids a network
/// request when registering offline songs whose metadata is already available
/// locally (e.g. from [userOfflineSongs]).
Future<void> updateRecentlyPlayed(dynamic songId, {Map? songFallback}) async {
  try {
    final now = DateTime.now();

    if (userRecentlyPlayed.value.isNotEmpty &&
        userRecentlyPlayed.value[0]['ytid'] == songId) {
      final updatedList = List.from(userRecentlyPlayed.value);
      final existing = Map.from(updatedList[0] as Map);
      existing['listeningCount'] = (existing['listeningCount'] ?? 0) + 1;
      existing['lastPlayed'] = now;
      updatedList[0] = existing;
      userRecentlyPlayed.value = updatedList;
      unawaited(
        addOrUpdateData<List>(
          'user',
          'recentlyPlayedSongs',
          userRecentlyPlayed.value,
        ),
      );
      // Report playback to YouTube Music history (even if streamed via JioSaavn)
      if (YouTubeAuthService().isSignedIn.value && ytReportHistory.value) {
        unawaited(
          YouTubeMusicSyncService().reportSongPlayed(songId.toString()),
        );
      }
      return;
    }

    final existingIndex = userRecentlyPlayed.value.indexWhere(
      (song) => song['ytid'] == songId,
    );

    final updatedList = List.from(userRecentlyPlayed.value);

    if (existingIndex == -1 && updatedList.length >= recentlyPlayedSongsLimit) {
      updatedList.removeLast();
    }

    if (existingIndex != -1) {
      final song = Map.from(updatedList.removeAt(existingIndex) as Map);
      song['listeningCount'] = (song['listeningCount'] ?? 0) + 1;
      song['lastPlayed'] = now;
      updatedList.insert(0, song);
    } else {
      final dynamic fetchedSongDetails = songFallback != null
          ? Map<String, dynamic>.from(songFallback)
          : await getSongDetails(0, songId);

      if (fetchedSongDetails is! Map) {
        logger.log('Failed to update recently played: invalid song details');
        return;
      }

      final newSongDetails = Map<String, dynamic>.from(fetchedSongDetails);
      newSongDetails['ytid'] ??= songId;
      newSongDetails['listeningCount'] = 1;
      newSongDetails['lastPlayed'] = now;
      updatedList.insert(0, newSongDetails);
    }

    userRecentlyPlayed.value = updatedList;
    unawaited(
      addOrUpdateData<List>(
        'user',
        'recentlyPlayedSongs',
        userRecentlyPlayed.value,
      ),
    );
    // Report playback to YouTube Music history (even if streamed via JioSaavn)
    if (YouTubeAuthService().isSignedIn.value && ytReportHistory.value) {
      unawaited(YouTubeMusicSyncService().reportSongPlayed(songId.toString()));
    }
  } catch (e, stackTrace) {
    logger.log(
      'Error updating recently played',
      error: e,
      stackTrace: stackTrace,
    );
  }
}

Future<void> removeFromRecentlyPlayed(dynamic songId) async {
  if (userRecentlyPlayed.value.any((song) => song['ytid'] == songId)) {
    userRecentlyPlayed.value = List.from(userRecentlyPlayed.value)
      ..removeWhere((song) => song['ytid'] == songId);
    unawaited(
      addOrUpdateData<List>(
        'user',
        'recentlyPlayedSongs',
        userRecentlyPlayed.value,
      ),
    );
  }
}
