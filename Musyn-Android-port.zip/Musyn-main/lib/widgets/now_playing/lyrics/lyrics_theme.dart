import 'package:flutter/cupertino.dart';
import 'package:musyn/theme/musyn_style.dart';

/// Visual tokens for live / synced lyrics.
///
/// Active line: center-aligned, highlighted in accent pink, bold, large.
/// Past lines: readable, muted text behind the current line.
/// Future lines: receding text with enough contrast to follow along.
class LyricsTheme {
  LyricsTheme({required this.isDark, required Color accent})
    : accent = accent == CupertinoColors.activeBlue
          ? MusynStyle.appleRed
          : accent;

  final bool isDark;
  final Color accent;

  Color get canvas =>
      isDark ? const Color(0xFF0A0A0E) : const Color(0xFFF2F2F7);

  Color get onCanvas => isDark ? CupertinoColors.white : CupertinoColors.black;

  /// Active line matches Apple Music signature high-contrast typography.
  Color get activeColor =>
      isDark ? const Color(0xFFFF8FB1) : const Color(0xFFAD1648);

  /// Past lines — clearly visible but receded.
  Color get pastColor => onCanvas.withValues(alpha: isDark ? 0.55 : 0.50);

  /// Future / upcoming lines — very dim.
  Color get futureColor => onCanvas.withValues(alpha: 0.42);

  // Keep muted/faint/hairline/chipFill for other widgets that use LyricsTheme.
  Color get muted => onCanvas.withValues(alpha: isDark ? 0.45 : 0.40);

  Color get faint => onCanvas.withValues(alpha: isDark ? 0.28 : 0.25);

  Color get hairline =>
      isDark ? const Color(0x1AFFFFFF) : const Color(0x14000000);

  Color get chipFill =>
      isDark ? const Color(0x22FFFFFF) : const Color(0x12000000);

  Color lineColor({required bool isActive, required bool isPast}) {
    if (isActive) return activeColor;
    if (isPast) return pastColor;
    return futureColor;
  }

  double fontSize({required bool isActive, required LyricsLayout layout}) {
    switch (layout) {
      case LyricsLayout.compact:
        return isActive ? 21 : 17;
      case LyricsLayout.stage:
        return 28;
    }
  }

  FontWeight fontWeight({required bool isActive}) =>
      isActive ? FontWeight.w800 : FontWeight.w600;

  double letterSpacing({required bool isActive, required LyricsLayout layout}) {
    if (layout == LyricsLayout.stage && isActive) return -1;
    if (isActive) return -0.5;
    return -0.2;
  }

  TextStyle lineStyle({
    required bool isActive,
    required bool isPast,
    required LyricsLayout layout,
  }) {
    final color = lineColor(isActive: isActive, isPast: isPast);
    return TextStyle(
      fontFamily: MusynStyle.displayFont,
      fontSize: fontSize(isActive: isActive, layout: layout),
      fontWeight: fontWeight(isActive: isActive),
      letterSpacing: letterSpacing(isActive: isActive, layout: layout),
      height: layout == LyricsLayout.stage ? 1.25 : 1.20,
      color: color,
      decoration: TextDecoration.none,
    );
  }

  TextStyle plainBodyStyle(LyricsLayout layout) => TextStyle(
    fontFamily: MusynStyle.displayFont,
    fontSize: layout == LyricsLayout.compact ? 15 : 22,
    fontWeight: FontWeight.w600,
    letterSpacing: -0.2,
    height: 1.55,
    color: onCanvas.withValues(alpha: 0.88),
    decoration: TextDecoration.none,
  );

  TextStyle captionStyle() => TextStyle(
    fontFamily: MusynStyle.uiFont,
    fontSize: 11,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.6,
    color: muted,
    decoration: TextDecoration.none,
  );
}

enum LyricsLayout { compact, stage }
