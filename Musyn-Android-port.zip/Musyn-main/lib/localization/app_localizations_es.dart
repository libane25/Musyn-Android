// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get about => 'Acerca de';

  @override
  String get accentChangeMsg => 'Color de acento actualizado';

  @override
  String get accentColor => 'Color de acento';

  @override
  String get add => 'Agregar';

  @override
  String get addPlaylist => 'Añadir una playlist';

  @override
  String get addToLikedPlaylists =>
      'Agregar a listas de reproducción favoritas';

  @override
  String get addToLikedSongs => 'Agregar a canciones favoritas';

  @override
  String get addToPlaylist => 'Agregar a la lista de reproducción';

  @override
  String get addToQueue => 'Añadir a la cola';

  @override
  String get addedPlaylists => 'Listas de reproducción agregadas';

  @override
  String get addedSuccess => 'Agregado correctamente';

  @override
  String get addedToLikedSongs => 'Añadido a canciones que te gustan';

  @override
  String get album => 'Álbum';

  @override
  String get albums => 'Álbumes';

  @override
  String get allSongs => 'Todas las canciones';

  @override
  String get alreadyDownloading => 'Descargando';

  @override
  String get annualRecap => 'Resumen del año';

  @override
  String get appUpdateIsAvailable => 'Actualización disponible';

  @override
  String get artist => 'Artista';

  @override
  String get artistNotFound =>
      'Artista no encontrado. Comprueba los registros o inténtalo de nuevo.';

  @override
  String get artists => 'Artistas';

  @override
  String get audioQuality => 'Calidad de audio';

  @override
  String get audioQualityBadge => 'Mostrar insignia de calidad de audio';

  @override
  String get audioQualityBadgeDescription =>
      'Mostrar una pequeña insignia de bitrate/codec en el artwork que se está ejecutando.';

  @override
  String get audioQualityHigh => 'Alta';

  @override
  String get audioQualityLow => 'Baja';

  @override
  String get audioQualityMedium => 'Media';

  @override
  String get audioQualityMsg => 'Calidad de audio actualizada';

  @override
  String get automaticSongPicker => 'Selector automático de canciones';

  @override
  String get automaticSongPickerDescription =>
      'Reproduce una canción al azar cuando la canción termine.';

  @override
  String get automaticUpdateChecks => 'Comprobar actualizaciones';

  @override
  String get automaticUpdateChecksDescription =>
      'Actualizar automáticamente la app al iniciar.';

  @override
  String get back => 'Retroceder';

  @override
  String get backToFavorites => 'Volver a favoritos';

  @override
  String get backedupSuccess => 'Datos respaldados correctamente';

  @override
  String get backupError => 'Error al respaldar los datos';

  @override
  String get backupUserData => 'Respaldar datos del usuario';

  @override
  String get becomeSponsor => 'Convertirse en patrocinador';

  @override
  String get cacheMsg => 'Caché eliminada';

  @override
  String get cancel => 'Cancelar';

  @override
  String get cancellingDownload => 'Cancelando Descarga...';

  @override
  String get checkForUpdates => '¿Comprobar actualizaciones?';

  @override
  String get chooseBackupDir => 'Seleccionar carpeta de respaldo';

  @override
  String get chooseBackupFiles => 'Elegir ficheros de respaldo';

  @override
  String get clear => 'Borrar';

  @override
  String get clearCache => 'Borrar caché';

  @override
  String get clearListeningStats => 'Borrar estadísticas de reproducción';

  @override
  String get clearListeningStatsQuestion =>
      'Esto eliminará las estadísticas de reproducción de la Máquina del Tiempo almacenadas en este dispositivo. ¿Continuar?';

  @override
  String get clearQueue => 'Borrar cola';

  @override
  String get clearQueueQuestion => '¿Borrar lista de reproducción?';

  @override
  String get clearRecentlyPlayed => 'Borrar reproducido recientemente';

  @override
  String get clearRecentlyPlayedQuestion =>
      '¿Borrar el historial de reproducción reciente?';

  @override
  String get clearSearchHistory => 'Borrar historial de búsqueda';

  @override
  String get clearSearchHistoryQuestion => '¿Borrar el historial de búsqueda?';

  @override
  String get copy => 'Copy';

  @override
  String get confirm => 'Confirmar';

  @override
  String get confirmation => 'Confirmación';

  @override
  String get copyLogs => 'Copiar registros';

  @override
  String get copyLogsNoLogs => 'No hay registros para copiar';

  @override
  String get copyLogsSuccess => 'Registros copiados correctamente';

  @override
  String get create => 'Crear';

  @override
  String get createFolder => 'Crear carpeta';

  @override
  String get custom => 'Personalizado';

  @override
  String get customPlaylistImgUrl =>
      'URL de imagen personalizada para la lista de reproducción';

  @override
  String get customPlaylistName =>
      'Nombre personalizado de la lista de reproducción';

  @override
  String get customPlaylists => 'Listas de reproducción personalizadas';

  @override
  String get dateAdded => 'Fecha agregada';

  @override
  String get default_ => 'Predeterminado';

  @override
  String get delete => 'Eliminar';

  @override
  String get deleteDownloads => 'Eliminar Descargas';

  @override
  String get deleteDownloadsQuestion =>
      '¿Seguro que quieres borrar las descargas?';

  @override
  String get deleteFolder => 'Eliminar carpeta';

  @override
  String get deleteFolderQuestion =>
      '¿Estás seguro de que deseas eliminar esta carpeta? Las listas de reproducción que contiene se moverán a la biblioteca principal.';

  @override
  String get deletePlaylist => 'Borrar lista de reproducción';

  @override
  String get download => 'Descargar';

  @override
  String get downloadAppUpdate => 'Descargar actualización de la aplicación';

  @override
  String get downloadCancelled => 'Descarga cancelada';

  @override
  String get downloadFailed => 'Descarga fallida';

  @override
  String get downloadPlaylist => 'Descargar lista de reproducción';

  @override
  String get downloadsDeleted => 'Descargas eliminadas exitosamente';

  @override
  String get dynamicColor => 'Color de acento dinámico';

  @override
  String get dynamicColorDescription =>
      'Utiliza los colores de acento de tu tema del sistema.';

  @override
  String get editFolder => 'Editar carpeta';

  @override
  String get editPlaylist => 'Edita la playlist';

  @override
  String get emptyFolderMsg =>
      'Esta carpeta está vacía. Añade listas de reproducción para organizar tu música.';

  @override
  String get enableUpdateChecksDescription =>
      '¿Desea que Musyn compruebe automáticamente si hay actualizaciones disponibles en las versiones de GitHub? Siempre puedes comprobar si hay actualizaciones manualmente desde los ajustes';

  @override
  String get endOfSong => 'Fin de canción';

  @override
  String get enterFolderName =>
      'Por favor, introduzca un nombre para la carpeta';

  @override
  String get equalizer => 'Ecualizador';

  @override
  String get equalizerBands => 'Bandas';

  @override
  String get equalizerDisabledHint =>
      'Se omiten los ajustes de ganancia de banda.';

  @override
  String get equalizerEnable => 'Activar ecualizador';

  @override
  String get equalizerEnabledHint =>
      'El ajuste de ganancia en banda está activo.';

  @override
  String get equalizerInitFailed =>
      'Ecualizador no se puede iniciar, prueba con otra canción y actualiza está página.';

  @override
  String get equalizerPresetBalanced => 'Balanceado';

  @override
  String get equalizerPresetBassBoost => 'Amplificador de bajo';

  @override
  String get equalizerPresetElectronic => 'Electrónica';

  @override
  String get equalizerPresetPop => 'Pop';

  @override
  String get equalizerPresetRock => 'Rock';

  @override
  String get equalizerPresetTrebleBoost => 'Amplificador de agudos';

  @override
  String get equalizerPresetVocal => 'Voces';

  @override
  String get equalizerPresets => 'Ajustes predefinidos';

  @override
  String get equalizerResetBands => 'Reiniciar bandas';

  @override
  String get error => 'Ocurrió un error. Por favor, inténtalo nuevamente.';

  @override
  String get externalRecommendations => 'Recomendaciones externas';

  @override
  String get externalRecommendationsDescription =>
      'Usar un algoritmo externo para recomendaciones en vez del de Musyn.';

  @override
  String get failedPlayingRadio => 'Error al reproducir la emisora de radio';

  @override
  String get failedToLoadPlaylist => 'Fallo en cargar la lista de reproducción';

  @override
  String get fieldsNotEmpty => 'Todos los campos deben ser llenados';

  @override
  String get folderAlreadyExists => 'Ya existe una carpeta con este nombre';

  @override
  String get folderDeleted => 'Carpeta eliminada correctamente';

  @override
  String get folderName => 'Nombre de la carpeta';

  @override
  String get folderUpdated => 'Carpeta actualizada exitosamente';

  @override
  String get goToArtist => 'Ir al artista';

  @override
  String get home => 'Inicio';

  @override
  String get hours => 'Horas';

  @override
  String get imagePicked => 'Imagen seleccionada';

  @override
  String get importSpotifyPlaylist => 'Import playlist from Spotify';

  @override
  String get importSpotifyPlaylistTitle => 'Import Spotify playlist';

  @override
  String get importSpotifyPlaylistInstructions =>
      'Export your Spotify playlist as CSV at chosic.com/spotify-playlist-exporter/, then choose the file or paste its contents below. Musyn will search YouTube for each song.';

  @override
  String get chooseCsvFile => 'Choose CSV file';

  @override
  String get openChosicExporter => 'Open Chosic Spotify exporter';

  @override
  String get pasteCsv => 'Paste CSV';

  @override
  String get playlistName => 'Playlist name';

  @override
  String get importPlaylist => 'Import playlist';

  @override
  String get spotifyCsvHint => 'Paste CSV content here';

  @override
  String get spotifyPlaylistNameHint => 'Imported Spotify playlist';

  @override
  String get spotifyPlaylistEmpty =>
      'Choose a CSV file or paste CSV content first';

  @override
  String get enterPlaylistName => 'Please enter a playlist name';

  @override
  String get spotifyPlaylistInvalid =>
      'The CSV does not contain Song and Artist columns';

  @override
  String get spotifyPlaylistImporting => 'Importing playlist...';

  @override
  String spotifyPlaylistImportResult(Object found, Object total) {
    return '$found of $total songs imported';
  }

  @override
  String spotifyPlaylistProgress(Object done, Object total) {
    return 'Searching $done of $total';
  }

  @override
  String get spotifyPlaylistAlreadyImporting =>
      'An import is already in progress';

  @override
  String get spotifyPlaylistMissingSongs => 'Songs not found';

  @override
  String get spotifyPlaylistImportFailed => 'Playlist import failed';

  @override
  String get invalidYouTubePlaylist =>
      'Lista de reproducción de YouTube no válida';

  @override
  String get language => 'Idioma';

  @override
  String get languageDe => 'Alemán';

  @override
  String get languageEl => 'Griego';

  @override
  String get languageEn => 'Inglés';

  @override
  String get languageEs => 'Español';

  @override
  String get languageEt => 'Estonio';

  @override
  String get languageFr => 'Francés';

  @override
  String get languageHe => 'Hebreo';

  @override
  String get languageHi => 'Hindi';

  @override
  String get languageHu => 'Húngaro';

  @override
  String get languageId => 'Indonesio';

  @override
  String get languageIt => 'Italiano';

  @override
  String get languageJa => 'Japonés';

  @override
  String get languageKo => 'Coreano';

  @override
  String get languageMsg => 'Se ha cambiado el idioma';

  @override
  String get languagePl => 'Polaco';

  @override
  String get languagePt => 'Portugués';

  @override
  String get languageRu => 'Ruso';

  @override
  String get languageSv => 'Sueco';

  @override
  String get languageTa => 'Tamil';

  @override
  String get languageTr => 'Turco';

  @override
  String get languageUk => 'Ucraniano';

  @override
  String get languageZh => 'Chino (Simplificado)';

  @override
  String get languageZhHant => 'Chino (Tradicional)';

  @override
  String get library => 'Biblioteca';

  @override
  String get licenses => 'Licencias';

  @override
  String get likedPlaylists => 'Listas de reproducción que te gustan';

  @override
  String get likedSongs => 'Canciones que te gustan';

  @override
  String get linkCopied => 'Link de la playlist copiado al tablero';

  @override
  String get listeningStats => 'Estadísticas de reproducción';

  @override
  String get listeningStatsCleared => 'Estadísticas de reproducción borradas';

  @override
  String get listeningStatsDescription =>
      'Registra tus estadísticas de reproducción para los resúmenes mensuales y anuales.';

  @override
  String get loading => 'Cargando';

  @override
  String get lyrics => 'Letras';

  @override
  String get lyricsNotAvailable => 'No hay letras disponibles';

  @override
  String get makeOffline => 'Disponible sin conexión';

  @override
  String get minutes => 'Minutos';

  @override
  String get minutesListened => 'minutos reproducidos';

  @override
  String get monthlyListeners => 'oyentes mensuales';

  @override
  String get moreOptions => 'Más opciones';

  @override
  String get mostPlayed => 'Lo más escuchado';

  @override
  String get moveToFolder => 'Mover a la carpeta';

  @override
  String get name => 'Nombre';

  @override
  String get newAnnouncement => 'Nuevo anuncio publicado';

  @override
  String get newFolder => 'Nueva carpeta';

  @override
  String get no => 'No';

  @override
  String get noCustomPlaylists =>
      'Aún no se han creado listas de reproducción personalizadas';

  @override
  String get noFolders => 'No hay carpetas creadas';

  @override
  String get noListeningStats => 'Aún no hay estadísticas de reproducción';

  @override
  String get noOfflineLibraryContent =>
      'No hay contenido descargado. Habilita el modo en línea o descarga playlists/canciones para usar está función.';

  @override
  String get noPlaylistsAdded => 'Aún no se han añadido listas de reproducción';

  @override
  String get noRadioStations => 'No hay emisoras de radio disponibles';

  @override
  String get noSongsInPlaylist => 'No hay canciones en la playlist';

  @override
  String get noSongsInQueue => 'No hay canciones en cola';

  @override
  String get notYTlist => 'ID de lista de reproducción de YouTube no válido';

  @override
  String get offlineMode => 'Modo sin conexión';

  @override
  String get offlineModeDescription =>
      'Desactive las funciones en línea y use Musyn completamente sin conexión.';

  @override
  String get offlinePlaylists => 'Offline playlists';

  @override
  String get offlineSongs => 'Canciones sin conexión';

  @override
  String get others => 'Otros';

  @override
  String get pause => 'Detener';

  @override
  String get pickImageFromDevice => 'Seleccionar imagen del dispositivo';

  @override
  String get pinToLibrary => 'Fijar a la librería';

  @override
  String get pinnedPlaylists => 'Playlists fijadas';

  @override
  String get pinnedPlaylistsLimit => 'Puedes fijar hasta 5 playlists o álbumes';

  @override
  String get play => 'Reproducir';

  @override
  String get playNext => 'Reproducir siguiente';

  @override
  String get playlist => 'Lista de reproducción';

  @override
  String get playlistAlreadyDownloaded => 'Lista de reproducción ya descargada';

  @override
  String get playlistAlreadyExists => 'La lista de reproducción ya existe';

  @override
  String get playlistDownloaded => 'Lista de reproducción descargada';

  @override
  String get playlistEmpty => 'La lista de reproducción está vacía';

  @override
  String get playlistFolders => 'Carpetas de listas de reproducción';

  @override
  String get playlistRemovedFromOffline =>
      'Lista de reproducción eliminada del almacenamiento sin conexión';

  @override
  String get playlistUpdated => 'Lista de reproducción actualizada';

  @override
  String get playlists => 'Listas de reproducción';

  @override
  String get preferences => 'Preferencias';

  @override
  String get provideIdOrNameError =>
      'Por favor, proporciona un ID de YouTube o un nombre personalizado para la lista de reproducción';

  @override
  String get pureBlackTheme => 'Tema negro puro';

  @override
  String get pureBlackThemeDescription =>
      'Utilice un verdadero fondo negro en modo oscuro para pantallas OLED.';

  @override
  String get queue => 'Cola';

  @override
  String get radioStations => 'Emisoras de radio';

  @override
  String get recentlyPlayed => 'Reproducido recientemente';

  @override
  String get recentlyPlayedMsg => 'Historial de reproducción reciente borrado';

  @override
  String get recommendedForYou => 'Recomendado para ti';

  @override
  String get remove => 'Eliminar';

  @override
  String get removeFromFolder => 'Eliminar de la carpeta';

  @override
  String get removeFromLikedPlaylists =>
      'Eliminar de las listas de reproducción favoritas';

  @override
  String get removeFromLikedSongs => 'Eliminar de las canciones favoritas';

  @override
  String get removeFromPlaylist => 'Eliminar de la lista de reproducción';

  @override
  String get removeFromRecentlyPlayed =>
      'Eliminar de reproducidos recientemente';

  @override
  String get removeOffline => 'Eliminar de sin conexión';

  @override
  String get removeOfflinePlaylist =>
      'Eliminar lista de reproducción sin conexión';

  @override
  String get removeOfflinePlaylistConfirm =>
      'Esto eliminará la lista de reproducción del almacenamiento sin conexión. Las canciones que se utilizan en otras listas de reproducción seguirán estando disponibles.';

  @override
  String get removePlaylistQuestion => '¿Eliminar la lista de reproducción?';

  @override
  String get removeSearchQueryQuestion => '¿Eliminar la consulta de búsqueda?';

  @override
  String get removedFromLikedSongs => 'Eliminar de mis Me Gusta';

  @override
  String get renameSong => 'Renombrar canción';

  @override
  String get repeat => 'Repetir';

  @override
  String get replay => 'Volver a escuchar';

  @override
  String get restoreError => 'Error al restaurar los datos';

  @override
  String get restoreUserData => 'Restaurar datos del usuario';

  @override
  String get restoredSuccess => 'Restaurado';

  @override
  String get search => 'Buscar';

  @override
  String get searchHistoryMsg => 'Historial de búsqueda borrado';

  @override
  String get selectDuration => 'Seleccionar duración';

  @override
  String get setTimer => 'Ajustar temporizador';

  @override
  String get settingChangedMsg => 'Ajustes cambiados';

  @override
  String get settings => 'Ajustes';

  @override
  String get share => 'Compartir';

  @override
  String get shareRecap => 'Compartir resumen';

  @override
  String get shareTimeMachineText => 'Mi resumen de Musyn';

  @override
  String get shuffle => 'Mezclar';

  @override
  String get single => 'Single';

  @override
  String get singlesAndEps => 'Signles y EPs';

  @override
  String get skipToNext => 'Saltar a la siguiente';

  @override
  String get skipToPrevious => 'Volver a la anterior';

  @override
  String get sleepTimer => 'Temporizador de apagado';

  @override
  String get sleepTimerCancelled => 'Temporizador de apagado cancelado';

  @override
  String get sleepTimerSet => 'Temporizador de apagado programado';

  @override
  String get songAdded => 'Canción añadida';

  @override
  String get songAddedToOffline => 'La canción ya está disponible sin conexión';

  @override
  String get songAlreadyInPlaylist =>
      'La canción ya está en la lista de reproducción';

  @override
  String get songRemoved => 'Canción eliminada';

  @override
  String get songRemovedFromOffline =>
      'La canción ya no está disponible sin conexión';

  @override
  String get songs => 'Canciones';

  @override
  String get sponsorBlockDescription =>
      'Omita segmentos patrocinados en pistas admitidas.';

  @override
  String get sponsorProject => 'Patrocina el proyecto';

  @override
  String get suggestedArtists => 'Artistas sugeridos';

  @override
  String get suggestedPlaylists => 'Listas de reproducción sugeridas';

  @override
  String get tapToView => 'Pulsa para ver';

  @override
  String get themeMode => 'Modo de tema';

  @override
  String get themeModeDark => 'Oscuro';

  @override
  String get themeModeLight => 'Claro';

  @override
  String get themeModeSystem => 'Sistema';

  @override
  String get timeMachine => 'Máquina del Tiempo';

  @override
  String get tools => 'Herramientas';

  @override
  String get topSongs => 'Top de canciones';

  @override
  String get translate => 'Traducir';

  @override
  String get translateDescription =>
      'Ayuda a traducir Musyn a tu idioma en Crowdin.';

  @override
  String get understand => 'Entiendo';

  @override
  String get undo => 'Deshacer';

  @override
  String get unpinFromLibrary => 'Desfijar de la librería';

  @override
  String get update => 'Actualización';

  @override
  String get useProxy => 'Usar proxy';

  @override
  String get useProxyDescription =>
      'Usa el proxy solo cuando el streaming falle, uso innecesario puede interrumpir la reproducción.';

  @override
  String get userPlaylists => 'Listas de reproducción del usuario';

  @override
  String get yes => 'Si';

  @override
  String get youtubePlaylistLinkOrId =>
      'Enlace o ID de lista de reproducción de YouTube';
}
